import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('ROOT_ELEMENT_NOT_FOUND');

createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
