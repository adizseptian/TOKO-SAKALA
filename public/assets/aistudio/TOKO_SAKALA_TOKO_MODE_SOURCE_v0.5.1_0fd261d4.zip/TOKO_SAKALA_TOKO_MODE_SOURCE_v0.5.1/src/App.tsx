import { useMemo, useState, type ChangeEvent, type ReactNode } from 'react';
import {
  Activity, ArrowDownRight, ArrowRight, BadgeCheck, Banknote, BookOpenText, Calculator,
  Boxes, BriefcaseBusiness, CalendarDays, Check, ChevronDown, CircleHelp,
  ClipboardCheck, Clock3, FileChartColumn, History, Home, Info, Lightbulb,
  Menu, Package, Plus, ReceiptText, Settings2, ShieldCheck, ShoppingBasket,
  Sparkles, Store, Wallet, X, Trash2, Printer, RotateCcw, CircleDollarSign
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { calculatePurchasePreview } from '@/engine/v1/purchase-preview';
import { calculateStockCheckLineValue, calculateStockCheckPreview } from '@/engine/v1/stock-check-preview';
import { AI_INTEGRATION_CONNECTED, readAssistantPreference, writeAssistantPreference } from '@/ai-feature';

type Screen = 'beranda' | 'catat' | 'stok' | 'setoran' | 'lainnya' | 'barang' | 'belanja' | 'cek-sisa' | 'biaya' | 'laporan' | 'asisten' | 'riwayat' | 'pengaturan';
type PrimaryScreen = 'beranda' | 'catat' | 'stok' | 'setoran' | 'lainnya';
type Theme = 'light' | 'dark';
type NavItem = { id: PrimaryScreen; label: string; icon: LucideIcon };

const navigation: NavItem[] = [
  { id: 'beranda', label: 'Beranda', icon: Home },
  { id: 'catat', label: 'Catat', icon: Plus },
  { id: 'stok', label: 'Stok', icon: Package },
  { id: 'setoran', label: 'Setoran', icon: Banknote },
  { id: 'lainnya', label: 'Lainnya', icon: Menu }
];

const screenLabels: Record<Screen, string> = {
  beranda: 'Beranda', catat: 'Catat aktivitas', stok: 'Stok barang', setoran: 'Setoran karyawan', lainnya: 'Lainnya',
  barang: 'Daftar barang', belanja: 'Catat belanja', 'cek-sisa': 'Cek sisa barang', biaya: 'Biaya toko',
  laporan: 'Laporan', asisten: 'Asisten pencatatan', riwayat: 'Riwayat', pengaturan: 'Pengaturan'
};
const currentTitle = (id: Screen) => screenLabels[id] ?? 'TOKO SAKALA';
const primaryFor = (id: Screen): PrimaryScreen => {
  if (id === 'belanja' || id === 'biaya') return 'catat';
  if (id === 'barang' || id === 'cek-sisa') return 'stok';
  if (id === 'laporan' || id === 'asisten' || id === 'riwayat' || id === 'pengaturan') return 'lainnya';
  return id as PrimaryScreen;
};
const money = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value);
const browserStorage = (): Storage | null => { try { return typeof window === 'undefined' ? null : window.localStorage; } catch { return null; } };
const readThemePreference = (storage: Storage | null): Theme => { try { return storage?.getItem('sakala-theme-v1') === 'dark' ? 'dark' : 'light'; } catch { return 'light'; } };
const writeThemePreference = (theme: Theme, storage: Storage | null) => { try { storage?.setItem('sakala-theme-v1', theme); } catch { /* Preference is optional; the app stays usable without storage. */ } };

function StatusPill({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'good' | 'warn' | 'off' }) {
  return <span className={`status-pill status-${tone}`}><span className="status-dot" />{children}</span>;
}

function PageTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-title-row"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="page-description">{description}</p></div>{action ? <div className="page-title-action">{action}</div> : null}</div>;
}

function Note({ tone = 'info', title, children }: { tone?: 'info' | 'warning' | 'success'; title: string; children: ReactNode }) {
  const Icon = tone === 'warning' ? ShieldCheck : tone === 'success' ? BadgeCheck : Info;
  return <div className={`note note-${tone}`}><Icon size={18} aria-hidden="true" /><div><strong>{title}</strong><p>{children}</p></div></div>;
}

function EmptyPanel({ icon: Icon, title, description, action }: { icon: LucideIcon; title: string; description: string; action?: ReactNode }) {
  return <div className="empty-panel"><div className="empty-icon"><Icon size={22} /></div><h3>{title}</h3><p>{description}</p>{action ? <div className="empty-action">{action}</div> : null}</div>;
}

function AiToggle({ enabled, onChange }: { enabled: boolean; onChange: (next: boolean) => void }) {
  return <button type="button" className={`switch ${enabled ? 'switch-on' : ''}`} role="switch" aria-checked={enabled} onClick={() => onChange(!enabled)} aria-label={`Asisten AI ${enabled ? 'ON' : 'OFF'}`}><span className="switch-thumb" /></button>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('beranda');
  const [mobileNav, setMobileNav] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(() => readAssistantPreference(browserStorage()));
  const [theme, setTheme] = useState<Theme>(() => readThemePreference(browserStorage()));

  const changeAiPreference = (enabled: boolean) => {
    setAiEnabled(enabled);
    writeAssistantPreference(enabled, browserStorage());
  };
  const changeTheme = (next: Theme) => { setTheme(next); writeThemePreference(next, browserStorage()); };
  const navigate = (next: Screen) => { setScreen(next); setMobileNav(false); window.scrollTo({ top: 0, behavior: 'auto' }); };

  return <div className="app-frame" data-theme={theme}>
    {mobileNav ? <button className="mobile-scrim" aria-label="Tutup menu" onClick={() => setMobileNav(false)} /> : null}
    <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`} aria-label="Navigasi aplikasi">
      <div className="brand-row"><div className="brand-mark" aria-hidden="true">S</div><div className="brand-word"><strong>TOKO SAKALA</strong><span>CATAT MUDAH · PAHAM JELAS</span></div><button className="icon-button sidebar-close" onClick={() => setMobileNav(false)} aria-label="Tutup menu"><X size={18} /></button></div>
      <div className="side-section"><p className="side-label">MENU UTAMA</p><nav aria-label="Menu utama">{navigation.map((item) => <NavButton key={item.id} item={item} active={primaryFor(screen) === item.id} onClick={() => navigate(item.id)} />)}</nav></div>
      <div className="sidebar-bottom">
        <div className="project-state"><div className="project-state-heading"><ShieldCheck size={15} /><span>Mode pratinjau</span></div><p>Transaksi belum tersimpan. Jangan gunakan angka pratinjau sebagai catatan toko.</p><button className="text-button" onClick={() => navigate('pengaturan')}>Status aplikasi <ArrowRight size={13} /></button></div>
        <div className="sidebar-foot"><span>TOKO MODE</span><span className="foot-dot" /><span>Core tanpa AI</span></div>
      </div>
    </aside>

    <div className="workspace">
      <header className="topbar"><div className="topbar-left"><button className="icon-button mobile-menu" onClick={() => setMobileNav(true)} aria-label="Buka menu"><Menu size={19} /></button><div><p className="breadcrumb">TOKO SAKALA <span>/</span> {currentTitle(screen)}</p><div className="topbar-title">{currentTitle(screen)}</div></div></div><div className="topbar-actions"><StatusPill tone="warn">Pratinjau · belum tersimpan</StatusPill><button type="button" className="button button-primary button-small" onClick={() => navigate('catat')}><Plus size={16} /> <span>Catat</span></button></div></header>
      <main className="page-content">
        <div className="global-banner"><div className="banner-icon"><Info size={17} /></div><div><strong>Mode pengembangan — data nyata belum aktif</strong><p>Perhitungan yang tampil adalah pratinjau. Belum ada transaksi yang disimpan ke database.</p></div><span className="banner-tag">PREVIEW</span></div>
        {screen === 'beranda' ? <Dashboard onNavigate={navigate} aiEnabled={aiEnabled} /> : null}
        {screen === 'catat' ? <CaptureHub onNavigate={navigate} /> : null}
        {screen === 'stok' ? <StockHub onNavigate={navigate} /> : null}
        {screen === 'lainnya' ? <MoreHub onNavigate={navigate} aiEnabled={aiEnabled} /> : null}
        {screen === 'barang' ? <ProductsPage onNavigate={navigate} /> : null}
        {screen === 'belanja' ? <PurchasePage /> : null}
        {screen === 'cek-sisa' ? <StockCheckPage /> : null}
        {screen === 'biaya' ? <ExpensePage /> : null}
        {screen === 'setoran' ? <CashPage /> : null}
        {screen === 'laporan' ? <ReportsPage /> : null}
        {screen === 'asisten' ? <AssistantPage enabled={aiEnabled} onToggle={changeAiPreference} onSettings={() => navigate('pengaturan')} /> : null}
        {screen === 'riwayat' ? <HistoryPage /> : null}
        {screen === 'pengaturan' ? <SettingsPage enabled={aiEnabled} onToggle={changeAiPreference} theme={theme} onThemeChange={changeTheme} /> : null}
        <footer className="main-footer"><span>TOKO SAKALA <span className="footer-sep">·</span> Sederhana di depan, akurat di belakang.</span><span>Starter UI · transaksi nyata belum diaktifkan</span></footer>
      </main>
    </div>
    <nav className="mobile-bottom-nav" aria-label="Navigasi utama">{navigation.map((item) => <button type="button" key={item.id} className={primaryFor(screen) === item.id ? 'mobile-nav-active' : ''} onClick={() => navigate(item.id)} aria-current={primaryFor(screen) === item.id ? 'page' : undefined}><item.icon size={19} strokeWidth={primaryFor(screen) === item.id ? 2.2 : 1.8} /><span>{item.label}</span></button>)}</nav>
  </div>;
}

function NavButton({ item, active, onClick }: { item: NavItem; active: boolean; onClick: () => void }) {
  const Icon = item.icon;
  return <button type="button" className={`nav-link ${active ? 'nav-link-active' : ''}`} onClick={onClick} aria-current={active ? 'page' : undefined}><Icon size={18} strokeWidth={active ? 2.2 : 1.8} /><span>{item.label}</span>{active ? <span className="nav-current-mark" aria-hidden="true" /> : null}</button>;
}

function Dashboard({ onNavigate, aiEnabled }: { onNavigate: (screen: Screen) => void; aiEnabled: boolean }) {
  return <div className="content-stack home-page">
    <PageTitle eyebrow="RINGKASAN TOKO" title="Halo, selamat datang." description="Catat apa yang terjadi. TOKO SAKALA membantu merapikan hitungannya." action={<button className="button button-primary" onClick={() => onNavigate('catat')}><Plus size={17} /> Mulai mencatat</button>} />
    <section className="home-status-panel" aria-labelledby="home-status-title">
      <div className="home-status-top"><span className="home-status-icon"><Store size={19} /></span><StatusPill tone="warn">Belum ada data tersimpan</StatusPill></div>
      <div className="home-status-copy"><h2 id="home-status-title">Toko belum memiliki catatan aktif.</h2><p>Mulai dari kejadian yang memang terjadi hari ini. Angka ringkasan akan muncul setelah catatan tersimpan dan tervalidasi.</p></div>
      <div className="home-status-actions"><button className="button button-primary" onClick={() => onNavigate('catat')}>Pilih yang mau dicatat <ArrowRight size={16} /></button><button className="button button-secondary" onClick={() => onNavigate('stok')}>Lihat alur stok</button></div>
    </section>
    <section className="home-summary-section"><div className="section-heading"><div><p className="eyebrow">RINGKASAN</p><h2>Angka toko</h2></div><span className="section-caption"><Clock3 size={14} /> Menunggu catatan pertama</span></div>
      <div className="home-summary-grid">
        <article className="home-summary-item"><span>Untung</span><strong>Belum diketahui</strong><p>Belum ada transaksi yang dapat dihitung.</p></article>
        <article className="home-summary-item"><span>Uang yang perlu diserahkan</span><strong>Belum diketahui</strong><p>Belum ada catatan uang yang tervalidasi.</p></article>
        <article className="home-summary-item"><span>Setoran karyawan</span><strong>Belum ada catatan</strong><p>Setoran adalah uang yang diserahkan kepada owner.</p></article>
      </div>
      <p className="home-footnote"><Info size={15} /> Nilai yang belum diketahui tidak dianggap nol.</p>
    </section>
    <section className="home-tasks-section"><div className="section-heading"><div><p className="eyebrow">LANGKAH UTAMA</p><h2>Hari ini di toko</h2></div></div>
      <div className="home-task-list">
        <button className="home-task" onClick={() => onNavigate('belanja')}><span className="home-task-number">01</span><span className="home-task-icon"><ShoppingBasket size={19} /></span><span className="home-task-copy"><strong>Catat belanja</strong><small>Barang masuk dan harga beli</small></span><ArrowRight size={17} /></button>
        <button className="home-task" onClick={() => onNavigate('cek-sisa')}><span className="home-task-number">02</span><span className="home-task-icon"><ClipboardCheck size={19} /></span><span className="home-task-copy"><strong>Cek sisa barang</strong><small>Isi jumlah yang benar-benar tersisa</small></span><ArrowRight size={17} /></button>
        <button className="home-task" onClick={() => onNavigate('biaya')}><span className="home-task-number">03</span><span className="home-task-icon"><ReceiptText size={19} /></span><span className="home-task-copy"><strong>Catat biaya toko</strong><small>Gas, plastik, es batu, atau sabun</small></span><ArrowRight size={17} /></button>
        <button className="home-task" onClick={() => onNavigate('setoran')}><span className="home-task-number">04</span><span className="home-task-icon"><Banknote size={19} /></span><span className="home-task-copy"><strong>Periksa setoran</strong><small>Bandingkan catatan dengan uang aktual</small></span><ArrowRight size={17} /></button>
      </div>
    </section>
    <section className="home-system-note"><ShieldCheck size={19} /><div><strong>Aplikasi masih dalam tahap pratinjau</strong><p>{aiEnabled ? 'Tampilan Asisten sedang ON, tetapi AI belum tersambung.' : 'Pencatatan inti dirancang berjalan tanpa AI.'} Jangan masukkan data toko sungguhan sampai penyimpanan, validasi, keamanan, dan pemulihan data diuji.</p><button className="text-button" onClick={() => onNavigate('pengaturan')}>Lihat status aplikasi <ArrowRight size={13} /></button></div></section>
  </div>;
}

function CaptureHub({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  return <div className="content-stack hub-page"><PageTitle eyebrow="CATAT KEJADIAN" title="Apa yang terjadi di toko?" description="Pilih kejadian. Kamu tidak perlu menghitung dampaknya sendiri." />
    <div className="hub-list">
      <HubAction icon={ShoppingBasket} number="01" title="Belanja barang" description="Catat kemasan, isi, dan harga beli." actionLabel="Catat belanja" onClick={() => onNavigate('belanja')} />
      <HubAction icon={ReceiptText} number="02" title="Pengeluaran toko" description="Catat biaya seperti gas, es batu, plastik, atau sabun." actionLabel="Catat biaya" onClick={() => onNavigate('biaya')} />
      <HubAction icon={CircleDollarSign} number="03" title="Pendapatan lain" description="Contohnya uang dari jasa seduh mi. Form ini belum tersedia." actionLabel="Belum tersedia" onClick={() => {}} disabled />
      <HubAction icon={ShieldCheck} number="04" title="Barang rusak atau dipakai" description="Pisahkan dari penjualan agar stok tidak dihitung keliru." actionLabel="Belum tersedia" onClick={() => {}} disabled />
      <HubAction icon={ClipboardCheck} number="05" title="Cek sisa barang" description="Masukkan sisa fisik; sistem akan menyiapkan pratinjau." actionLabel="Cek sisa" onClick={() => onNavigate('cek-sisa')} />
      <HubAction icon={Banknote} number="06" title="Periksa setoran" description="Lihat status dan arti selisih, jika catatan tersedia." actionLabel="Periksa setoran" onClick={() => onNavigate('setoran')} />
    </div>
    <Note tone="warning" title="Pratinjau saja">Form yang tersedia belum menyimpan transaksi. Jangan memakai hasil di halaman ini sebagai pembukuan nyata.</Note>
  </div>;
}

function HubAction({ icon: Icon, number, title, description, actionLabel, onClick, disabled = false }: { icon: LucideIcon; number: string; title: string; description: string; actionLabel: string; onClick: () => void; disabled?: boolean }) {
  return <button type="button" className={`hub-action ${disabled ? 'hub-action-disabled' : ''}`} onClick={onClick} disabled={disabled} aria-disabled={disabled || undefined}><span className="hub-action-number">{number}</span><span className="hub-action-icon"><Icon size={19} /></span><span className="hub-action-copy"><strong>{title}</strong><small>{description}</small></span><span className="hub-action-label">{actionLabel} <ArrowRight size={15} /></span></button>;
}

function StockHub({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  return <div className="content-stack hub-page"><PageTitle eyebrow="STOK BARANG" title="Stok yang terlihat, catatan yang jelas." description="Lihat master barang atau masukkan sisa fisik. Nilai kosong bukan berarti nol." />
    <div className="stock-entry-choices"><button type="button" className="stock-entry-choice stock-entry-primary" onClick={() => onNavigate('cek-sisa')}><span className="choice-icon"><ClipboardCheck size={21} /></span><span><strong>Cek sisa fisik</strong><small>Catat beberapa barang sekaligus.</small></span><ArrowRight size={18} /></button><button type="button" className="stock-entry-choice" onClick={() => onNavigate('barang')}><span className="choice-icon"><Package size={21} /></span><span><strong>Daftar barang</strong><small>Master barang dan harga yang tercatat.</small></span><ArrowRight size={18} /></button></div>
    <Note title="Tentang angka stok">Barang yang belum pernah dicek tidak dianggap nol atau habis. Jumlah terjual hanya dihitung saat data ketersediaan dan penyesuaian lain cukup jelas.</Note>
  </div>;
}

function MoreHub({ onNavigate, aiEnabled }: { onNavigate: (screen: Screen) => void; aiEnabled: boolean }) {
  return <div className="content-stack hub-page"><PageTitle eyebrow="MENU TAMBAHAN" title="Lihat dan atur aplikasi" description="Laporan, riwayat, dan pengaturan ada di sini agar tugas harian tetap ringkas." />
    <div className="more-list">
      <button type="button" className="more-item" onClick={() => onNavigate('laporan')}><span className="more-item-icon"><FileChartColumn size={19} /></span><span><strong>Laporan</strong><small>Ringkasan usaha dan hasil per periode.</small></span><ArrowRight size={17} /></button>
      <button type="button" className="more-item" onClick={() => onNavigate('riwayat')}><span className="more-item-icon"><History size={19} /></span><span><strong>Riwayat</strong><small>Telusuri perubahan yang tercatat.</small></span><ArrowRight size={17} /></button>
      <button type="button" className="more-item" onClick={() => onNavigate('asisten')}><span className="more-item-icon"><Sparkles size={19} /></span><span><strong>Asisten pencatatan</strong><small>{aiEnabled ? 'Tampilan ON, AI belum terhubung.' : 'Opsional; aplikasi inti tetap berjalan tanpa AI.'}</small></span><ArrowRight size={17} /></button>
      <button type="button" className="more-item" onClick={() => onNavigate('pengaturan')}><span className="more-item-icon"><Settings2 size={19} /></span><span><strong>Pengaturan</strong><small>Status aplikasi dan preferensi.</small></span><ArrowRight size={17} /></button>
    </div>
  </div>;
}

function QuickAction({ icon: Icon, title, description, onClick }: { icon: LucideIcon; title: string; description: string; onClick: () => void }) {
  return <button className="quick-action" onClick={onClick}><span className="quick-action-icon"><Icon size={18} /></span><span className="quick-action-copy"><strong>{title}</strong><span>{description}</span></span><ArrowRight className="quick-arrow" size={16} /></button>;
}

function ProductsPage({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  return <div className="content-stack"><PageTitle eyebrow="PENGELOLAAN BARANG" title="Barang" description="Daftar barang, satuan belanja, harga modal, harga jual, dan stok." action={<button className="button button-primary" onClick={() => onNavigate('belanja')}><Plus size={17} /> Catat belanja</button>} /><Note tone="warning" title="Daftar barang belum tersambung">Halaman ini belum membaca atau menyimpan data barang dari database.</Note><EmptyPanel icon={Boxes} title="Belum ada barang" description="Saat backend aktif, barang yang kamu tambahkan akan muncul di sini. Data awal tidak dibuat secara otomatis." action={<button className="button button-secondary" onClick={() => onNavigate('belanja')}>Lihat contoh hitungan belanja <ArrowRight size={15} /></button>} /></div>;
}

function PurchasePage() {
  const [productName, setProductName] = useState('');
  const [packs, setPacks] = useState('');
  const [unitsPerPack, setUnitsPerPack] = useState('');
  const [packCost, setPackCost] = useState('');
  const [sellingPrice, setSellingPrice] = useState('');
  const [source, setSource] = useState<'STORE' | 'PERSONAL' | 'UNKNOWN' | ''>('');
  const loadPurchaseExample = () => { setProductName('Mie Suksess'); setPacks('2'); setUnitsPerPack('24'); setPackCost('96000'); setSellingPrice('7000'); setSource('UNKNOWN'); };
  const preview = useMemo(() => calculatePurchasePreview({ packs: Number(packs), unitsPerPack: Number(unitsPerPack), costPerPack: Number(packCost), sellingPricePerUnit: Number(sellingPrice) }), [packs, unitsPerPack, packCost, sellingPrice]);
  const updateNumeric = (setter: (value: string) => void) => (event: ChangeEvent<HTMLInputElement>) => setter(event.target.value.replace(/[^\d]/g, ''));
  return <div className="content-stack"><PageTitle eyebrow="BARANG MASUK" title="Catat belanja" description="Masukkan jumlah kemasan dan harga. Sistem menghitung isi satuan serta modalnya." action={<button type="button" className="button button-secondary" onClick={loadPurchaseExample}><BookOpenText size={16} /> Isi contoh hitungan</button>} /><Note title="Ini pratinjau, bukan transaksi nyata">Form ini hanya menghitung di layar. Belum ada tombol penyimpanan yang aktif sampai backend aman tersedia.</Note><div className="purchase-layout"><section className="panel form-panel"><div className="panel-heading"><div><p className="eyebrow">INFORMASI BELANJA</p><h2>Barang yang dibeli</h2></div><span className="panel-heading-icon"><ReceiptText size={17} /></span></div><div className="form-body"><label className="field-label" htmlFor="productName">Nama barang</label><input id="productName" className="text-field" value={productName} onChange={(event) => setProductName(event.target.value)} placeholder="Contoh: Mie Suksess" maxLength={120} /><div className="field-grid"><div><label className="field-label" htmlFor="packs">Jumlah kemasan</label><div className="input-with-suffix"><input id="packs" className="text-field" inputMode="numeric" value={packs} onChange={updateNumeric(setPacks)} /><span>dus</span></div></div><div><label className="field-label" htmlFor="unitsPerPack">Isi per kemasan</label><div className="input-with-suffix"><input id="unitsPerPack" className="text-field" inputMode="numeric" value={unitsPerPack} onChange={updateNumeric(setUnitsPerPack)} /><span>pcs</span></div></div></div><div className="field-grid"><div><label className="field-label" htmlFor="packCost">Harga per kemasan</label><div className="input-with-prefix"><span>Rp</span><input id="packCost" className="text-field" inputMode="numeric" value={packCost} onChange={updateNumeric(setPackCost)} /></div></div><div><label className="field-label" htmlFor="sellingPrice">Harga jual per pcs</label><div className="input-with-prefix"><span>Rp</span><input id="sellingPrice" className="text-field" inputMode="numeric" value={sellingPrice} onChange={updateNumeric(setSellingPrice)} /></div></div></div><div className="field-divider" /><div><label className="field-label">Sumber uang belanja</label><p className="field-help">Pilih sesuai kejadian. Ini tidak disimpan pada pratinjau.</p><div className="choice-grid"><button type="button" className={`choice-card ${source === 'STORE' ? 'choice-selected' : ''}`} onClick={() => setSource('STORE')}><Wallet size={17} /><strong>Uang toko</strong><span>Uang toko berkurang</span></button><button type="button" className={`choice-card ${source === 'PERSONAL' ? 'choice-selected' : ''}`} onClick={() => setSource('PERSONAL')}><BriefcaseBusiness size={17} /><strong>Uang pribadi</strong><span>Kas toko tidak berkurang</span></button><button type="button" className={`choice-card ${source === 'UNKNOWN' ? 'choice-selected' : ''}`} onClick={() => setSource('UNKNOWN')}><CircleHelp size={17} /><strong>Belum tahu</strong><span>Hasil uang belum pasti</span></button></div></div><div className="form-footer"><button className="button button-disabled" disabled title="Penyimpanan belum diaktifkan"><Check size={16} /> Simpan belanja (belum aktif)</button><span><ShieldCheck size={14} /> Tidak ada data yang disimpan</span></div></div></section>
      <aside className="panel preview-panel"><div className="panel-heading"><div><p className="eyebrow">HASIL OTOMATIS</p><h2>Pratinjau belanja</h2></div><StatusPill tone="warn">Belum disimpan</StatusPill></div>{preview ? <><div className="preview-product"><span className="preview-box-icon"><Package size={20} /></span><div><strong>{productName.trim() || 'Nama barang belum diisi'}</strong><span>Hitungan dari angka yang kamu masukkan</span></div></div><div className="preview-stat"><span>Barang masuk</span><strong>{preview.totalUnits.toLocaleString('id-ID')} pcs</strong></div><div className="preview-stat"><span>Total modal</span><strong>{money(preview.totalCost)}</strong></div><div className="preview-stat"><span>Modal rata-rata per pcs</span><strong>{money(preview.unitCostRounded)}</strong></div><div className="preview-stat"><span>Selisih harga jual dan modal per pcs</span><strong className={preview.unitPriceDifference >= 0 ? 'value-positive' : 'value-negative'}>{money(preview.unitPriceDifference)}</strong></div><div className="preview-callout"><Lightbulb size={16} /><p>Nilai ini adalah pratinjau belanja. Bukan keuntungan final dan tidak termasuk pengeluaran toko.</p></div><div className="preview-cash"><div className="preview-cash-icon"><ArrowDownRight size={17} /></div><div><span>Sumber uang · {source === 'STORE' ? 'Uang toko' : source === 'PERSONAL' ? 'Uang pribadi' : source === 'UNKNOWN' ? 'Belum tahu' : 'Belum dipilih'}</span><strong>{source === 'STORE' ? `Keluar ${money(preview.totalCost)}` : source === 'PERSONAL' ? 'Tidak mengurangi uang toko' : source === 'UNKNOWN' ? 'Belum dapat dipastikan' : 'Pilih sumber uang belanja'}</strong></div></div></> : <EmptyPanel icon={Calculator} title="Periksa angka" description="Masukkan jumlah dan nominal bulat yang valid untuk melihat pratinjau." />}</aside></div><p className="footnote"><Info size={14} /> Nilai uang dibulatkan ke rupiah. Perhitungan final harus divalidasi lagi oleh server sebelum implementasi penyimpanan.</p></div>;
}


type StockDraftRow = { id: number; name: string; category: string; unit: string; remaining: string; sellingPrice: string };
type ExpenseDraftRow = { id: number; name: string; amount: string };
let stockDraftId = 100;
let expenseDraftId = 500;
const blankStockRow = (): StockDraftRow => ({ id: stockDraftId++, name: '', category: '', unit: '', remaining: '', sellingPrice: '' });
const blankExpenseRow = (): ExpenseDraftRow => ({ id: expenseDraftId++, name: '', amount: '' });
const digitsOnly = (value: string) => value.replace(/[^\d]/g, '');
const jakartaDateValue = () => { const parts = new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'Asia/Jakarta' }).formatToParts(new Date()); const part = (type: string) => parts.find((item) => item.type === type)?.value ?? ''; return `${part('year')}-${part('month')}-${part('day')}`; }

function safeStockLineValue(remaining: number, sellingPrice: number): number | null {
  try { return calculateStockCheckLineValue(remaining, sellingPrice); }
  catch { return null; }
}

function StockCheckPage() {
  const [rows, setRows] = useState<StockDraftRow[]>(() => Array.from({ length: 8 }, blankStockRow));
  const [expenses, setExpenses] = useState<ExpenseDraftRow[]>([]);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [notice, setNotice] = useState('');

  const stockCalculation = useMemo(() => {
    try {
      return { preview: calculateStockCheckPreview(rows.map((row) => ({
        id: row.id, name: row.name, category: row.category, unit: row.unit,
        remaining: row.remaining === '' || row.unit === '' ? null : Number(row.remaining),
        sellingPrice: row.sellingPrice === '' || row.unit === '' ? null : Number(row.sellingPrice)
      }))), error: '' };
    } catch {
      const entered = rows.filter((row) => row.name.trim() || row.category !== '' || row.unit !== '' || row.remaining !== '' || row.sellingPrice !== '');
      return { preview: { enteredRowIds: entered.map((row) => row.id), completeRowIds: [], incompleteRowIds: entered.map((row) => row.id), completeItemTypes: 0, remainingByUnit: {}, totalRetailValueOfRemainingStock: 0 }, error: 'Angka terlalu besar untuk dihitung dengan aman. Periksa jumlah sisa dan harga jual.' };
    }
  }, [rows]);
  const stockPreview = stockCalculation.preview;
  const completeRows = rows.filter((row) => stockPreview.completeRowIds.includes(row.id));
  const incompleteRows = stockPreview.incompleteRowIds.length;
  const stockRetailValue = stockPreview.totalRetailValueOfRemainingStock;
  const stockRetailValueLabel = stockCalculation.error ? 'Periksa angka' : money(stockRetailValue);
  const completeExpenses = expenses.filter((row) => row.name.trim() && row.amount !== '');
  const incompleteExpenses = expenses.filter((row) => (row.name.trim() || row.amount !== '') && !(row.name.trim() && row.amount !== '')).length;
  const expenseTotalRaw = completeExpenses.reduce((sum, row) => sum + Number(row.amount), 0);
  const expenseTotalSafe = Number.isSafeInteger(expenseTotalRaw);
  const expenseTotal = expenseTotalSafe ? expenseTotalRaw : 0;

  const updateStock = (id: number, key: keyof Omit<StockDraftRow, 'id'>, value: string) => {
    setRows((old) => old.map((row) => row.id === id ? { ...row, [key]: key === 'remaining' || key === 'sellingPrice' ? digitsOnly(value) : value } : row));
    setReviewOpen(false);
    setNotice('');
  };
  const updateExpense = (id: number, key: keyof Omit<ExpenseDraftRow, 'id'>, value: string) => {
    setExpenses((old) => old.map((row) => row.id === id ? { ...row, [key]: key === 'amount' ? digitsOnly(value) : value } : row));
    setReviewOpen(false);
    setNotice('');
  };
  const loadPaperExample = () => {
    const sample: Omit<StockDraftRow, 'id'>[] = [
      { name: 'Mie', category: 'Makanan', unit: 'pcs', remaining: '34', sellingPrice: '7000' },
      { name: 'Seblak', category: 'Makanan', unit: 'porsi', remaining: '79', sellingPrice: '1000' },
      { name: 'Saltchees', category: 'Makanan', unit: 'pcs', remaining: '25', sellingPrice: '1000' },
      { name: 'Malkis', category: 'Makanan', unit: 'pcs', remaining: '18', sellingPrice: '1000' },
      { name: 'Superco', category: 'Makanan', unit: 'pcs', remaining: '4', sellingPrice: '1000' },
      { name: 'Tic Tac', category: 'Makanan', unit: 'pcs', remaining: '6', sellingPrice: '1000' },
      { name: 'Mie Krispi', category: 'Makanan', unit: 'pcs', remaining: '5', sellingPrice: '1000' },
      { name: 'Cloud 9', category: 'Makanan', unit: 'pcs', remaining: '9', sellingPrice: '1000' },
      { name: 'Chocolatos', category: 'Makanan', unit: 'pcs', remaining: '35', sellingPrice: '1000' },
      { name: 'Pilus (cek nama)', category: 'Makanan', unit: 'pcs', remaining: '4', sellingPrice: '2000' },
      { name: 'Better', category: 'Makanan', unit: 'pcs', remaining: '8', sellingPrice: '2000' },
      { name: 'ChocoPie', category: 'Makanan', unit: '', remaining: '', sellingPrice: '' },
      { name: 'So Nice', category: 'Makanan', unit: 'pcs', remaining: '1', sellingPrice: '1000' },
      { name: 'Seblak ceker', category: 'Makanan', unit: 'porsi', remaining: '18', sellingPrice: '500' },
      { name: 'Sosis goreng', category: 'Makanan', unit: 'pcs', remaining: '2', sellingPrice: '500' },
      { name: 'Kukoya (cek nama)', category: 'Makanan', unit: 'pcs', remaining: '70', sellingPrice: '1000' }
    ];
    setRows(sample.map((row) => ({ ...row, unit: row.unit ?? '', id: stockDraftId++ })));
    setExpenses([]);
    setReviewOpen(false);
    setNotice('Contoh tabel dari foto dimuat. Ini hanya contoh di layar dan belum disimpan. Periksa nama barang yang tulisannya kurang jelas.');
  };
  const resetDraft = () => {
    setRows(Array.from({ length: 8 }, blankStockRow));
    setExpenses([]);
    setReviewOpen(false);
    setNotice('Form dikosongkan. Tidak ada transaksi yang dihapus karena data ini belum pernah disimpan.');
  };

  return <div className="content-stack stock-workflow-page">
    <PageTitle eyebrow="CATAT SEKALIGUS" title="Cek sisa barang" description="Hitung barang yang masih ada dalam satu tabel. Isi jumlah sisa; total akan dihitung otomatis." action={<div className="stock-title-actions"><button className="button button-secondary" onClick={loadPaperExample}><BookOpenText size={16} /> Lihat contoh tabel</button><button className="button button-secondary" onClick={() => window.print()}><Printer size={16} /> Cetak / Simpan PDF</button></div>} />
    <div className="stock-workflow-note"><span className="stock-note-icon"><Info size={18} /></span><div><strong>Form ini masih pratinjau, belum menyimpan data.</strong><p>Kamu bisa mencoba alurnya. Draf belum disimpan dan akan hilang jika keluar dari halaman atau memuat ulang. Jangan anggap angka di sini sebagai catatan toko resmi.</p></div><StatusPill tone="warn">Belum disimpan</StatusPill></div>

    {notice ? <div className="stock-inline-notice" role="status"><Info size={16} /><span>{notice}</span><button className="icon-button" onClick={() => setNotice('')} aria-label="Tutup pemberitahuan"><X size={15} /></button></div> : null}
    {stockCalculation.error ? <div className="stock-inline-notice stock-inline-error" role="alert"><ShieldCheck size={16} /><span>{stockCalculation.error}</span></div> : null}

    <section className="panel stock-sheet-panel">
      <div className="panel-heading stock-sheet-heading"><div><p className="eyebrow">LEMBAR CEK SISA</p><h2>Barang yang masih ada</h2><p className="panel-subtitle">Isi yang kamu tahu. Kategori boleh dikosongkan. Tentukan satuan hitung dan harga jual dengan satuan yang sama. Jumlah kg dan pcs tidak dijumlahkan sebagai satu angka.</p></div><span className="panel-heading-icon"><ClipboardCheck size={18} /></span></div>
      <div className="stock-sheet-table-wrap"><table className="stock-sheet-table"><thead><tr><th>No.</th><th>Nama barang</th><th>Kategori <span className="optional-label">opsional</span></th><th>Satuan hitung & jual</th><th>Sisa sekarang</th><th>Harga jual / satuan</th><th>Nilai sisa*</th><th aria-label="Aksi"></th></tr></thead>
        <tbody>{rows.map((row, index) => {
          const ready = Boolean(row.name.trim() && row.unit && row.remaining !== '' && row.sellingPrice !== '');
          const rowTotal = ready && !stockCalculation.error ? safeStockLineValue(Number(row.remaining), Number(row.sellingPrice)) : null;
          const partial = Boolean(row.name.trim() || row.unit !== '' || row.remaining !== '' || row.sellingPrice !== '' || row.category !== '');
          return <tr key={row.id} className={partial && !ready ? 'stock-row-incomplete' : ''}>
            <td className="stock-row-number">{index + 1}</td>
            <td><input className="sheet-input sheet-name" aria-label={`Nama barang baris ${index + 1}`} value={row.name} onChange={(e) => updateStock(row.id, 'name', e.target.value)} placeholder="Contoh: Mie" maxLength={80} /></td>
            <td><select className="sheet-input sheet-category" aria-label={`Kategori barang baris ${index + 1}`} value={row.category} onChange={(e) => updateStock(row.id, 'category', e.target.value)}><option value="">Pilih</option><option value="Makanan">Makanan</option><option value="Minuman">Minuman</option><option value="Kebutuhan toko">Kebutuhan toko</option><option value="Lainnya">Lainnya</option></select></td>
            <td><select className="sheet-input sheet-category" aria-label={`Satuan hitung dan jual baris ${index + 1}`} value={row.unit} onChange={(e) => updateStock(row.id, 'unit', e.target.value)}><option value="">Pilih satuan</option><option value="pcs">pcs</option><option value="bungkus">bungkus</option><option value="pak">pak</option><option value="dus">dus</option><option value="botol">botol</option><option value="cup">cup</option><option value="porsi">porsi</option><option value="kg">kg</option><option value="gram">gram</option><option value="liter">liter</option><option value="ml">ml</option></select></td>
            <td><div className="sheet-number-cell"><input className="sheet-input sheet-number" aria-label={`Sisa sekarang baris ${index + 1}`} inputMode="numeric" value={row.remaining} onChange={(e) => updateStock(row.id, 'remaining', e.target.value)} placeholder="Isi jumlah" /><span>{row.unit || 'satuan'}</span></div></td>
            <td><div className="sheet-price-cell"><span>Rp</span><input className="sheet-input sheet-number" aria-label={`Harga jual per satuan baris ${index + 1}`} inputMode="numeric" value={row.sellingPrice ? new Intl.NumberFormat('id-ID').format(Number(row.sellingPrice)) : ''} onChange={(e) => updateStock(row.id, 'sellingPrice', e.target.value)} placeholder="Isi harga" /></div></td>
            <td className="sheet-total-cell">{rowTotal === null ? <span className="sheet-dash">—</span> : money(rowTotal)}</td>
            <td><button className="sheet-remove" type="button" onClick={() => { setRows((old) => old.length > 1 ? old.filter((r) => r.id !== row.id) : old.map((r) => r.id === row.id ? blankStockRow() : r)); setReviewOpen(false); }} aria-label={`Hapus baris ${index + 1}`} title="Hapus baris"><Trash2 size={15} /></button></td>
          </tr>;
        })}</tbody>
        <tfoot><tr><td colSpan={4}>Ringkasan nilai</td><td colSpan={2}>{completeRows.length} barang terisi</td><td>{stockRetailValueLabel}</td><td></td></tr></tfoot>
      </table></div>
      <div className="stock-table-actions"><button className="button button-secondary" onClick={() => { setRows((old) => [...old, blankStockRow()]); setReviewOpen(false); }}><Plus size={16} /> Tambah baris barang</button><span>{incompleteRows > 0 ? `${incompleteRows} baris belum lengkap` : 'Isi nama, sisa, dan harga untuk menghitung total.'}</span></div>
      <div className="stock-calculation-note"><CircleDollarSign size={17} /><p><strong>*Nilai sisa menurut harga jual.</strong> Ini perkiraan nilai jika seluruh sisa barang terjual. Angka ini <u>bukan modal sisa</u> dan <u>bukan keuntungan</u>.</p></div>
    </section>

    <section className="panel stock-expense-panel">
      <div className="panel-heading"><div><p className="eyebrow">CATATAN TAMBAHAN</p><h2>Pengeluaran toko</h2><p className="panel-subtitle">Catat pengeluaran terpisah dari nilai barang yang tersisa.</p></div><span className="panel-heading-icon"><ReceiptText size={18} /></span></div>
      <div className="expense-quick-add"><span>Tambah cepat:</span>{['Gas', 'Plastik', 'Es batu', 'Sabun'].map((name) => <button key={name} type="button" className="quick-chip" onClick={() => { setExpenses((old) => [...old, { ...blankExpenseRow(), name }]); setReviewOpen(false); }}>{name} <Plus size={13} /></button>)}</div>
      {expenses.length ? <div className="expense-draft-list">{expenses.map((expense, index) => <div className="expense-draft-row" key={expense.id}><span className="expense-row-number">{index + 1}</span><input className="text-field" aria-label={`Nama pengeluaran ${index + 1}`} value={expense.name} onChange={(e) => updateExpense(expense.id, 'name', e.target.value)} placeholder="Contoh: Gas" maxLength={80} /><div className="input-with-prefix"><span>Rp</span><input className="text-field" aria-label={`Nominal pengeluaran ${index + 1}`} inputMode="numeric" value={expense.amount ? new Intl.NumberFormat('id-ID').format(Number(expense.amount)) : ''} onChange={(e) => updateExpense(expense.id, 'amount', e.target.value)} placeholder="0" /></div><button className="sheet-remove" type="button" onClick={() => { setExpenses((old) => old.filter((row) => row.id !== expense.id)); setReviewOpen(false); }} aria-label={`Hapus pengeluaran ${index + 1}`}><Trash2 size={15} /></button></div>)}</div> : <p className="expense-empty-hint">Belum ada pengeluaran yang ditulis. Tekan salah satu jenis di atas atau biarkan kosong.</p>}
      <div className="expense-summary-row"><span>Total pengeluaran yang diisi</span><strong>{expenseTotalSafe ? money(expenseTotal) : 'Angka terlalu besar'}</strong></div>
      {!expenseTotalSafe ? <p className="field-help stock-warning-text" role="alert">Total pengeluaran terlalu besar untuk dihitung dengan aman. Kurangi atau periksa nominal yang dimasukkan.</p> : null}
      {incompleteExpenses ? <p className="field-help stock-warning-text">Ada {incompleteExpenses} pengeluaran yang belum lengkap.</p> : null}
    </section>

    <section className="stock-summary-grid" aria-label="Ringkasan cek sisa"><article className="stock-summary-card"><span>Barang lengkap</span><strong>{completeRows.length}</strong><small>jenis barang</small></article><article className="stock-summary-card"><span>Belum lengkap</span><strong>{incompleteRows}</strong><small>baris perlu diperiksa</small></article><article className="stock-summary-card stock-summary-primary"><span>Nilai sisa pada harga jual</span><strong>{stockRetailValueLabel}</strong><small>Bukan modal atau keuntungan</small></article><article className="stock-summary-card"><span>Pengeluaran diisi</span><strong>{money(expenseTotal)}</strong><small>Belum termasuk hitungan untung</small></article></section>

    <section className="panel stock-review-panel"><div className="panel-heading"><div><p className="eyebrow">LANGKAH TERAKHIR</p><h2>Tinjau sebelum selesai</h2><p className="panel-subtitle">Pastikan nama, jumlah sisa, dan harga sudah benar.</p></div><span className="panel-heading-icon"><Check size={18} /></span></div>
      {reviewOpen ? <div className="stock-review-result" role="status"><div className="stock-review-result-heading"><BadgeCheck size={22} /><div><strong>Ringkasan siap diperiksa</strong><span>Ini masih pratinjau dan belum disimpan.</span></div></div><div className="stock-review-lines"><div><span>Jumlah barang lengkap</span><strong>{completeRows.length}</strong></div><div><span>Jumlah fisik</span><strong>Ditampilkan per barang sesuai satuannya</strong></div><div><span>Perkiraan nilai sisa menurut harga jual</span><strong>{money(stockRetailValue)}</strong></div><div><span>Total pengeluaran yang diisi</span><strong>{money(expenseTotal)}</strong></div><div><span>Keuntungan usaha</span><strong className="text-muted">Belum dapat dihitung dari form ini saja</strong></div></div>{incompleteRows || incompleteExpenses ? <p className="stock-review-warning">Masih ada {incompleteRows + incompleteExpenses} baris yang belum lengkap. Periksa atau kosongkan baris itu sebelum catatan nyata diaktifkan.</p> : null}<p className="field-help">Agar keuntungan benar, aplikasi perlu memakai harga modal barang dan riwayat transaksi yang sesuai. Nilai sisa menurut harga jual tidak boleh dikurangi sembarangan untuk menghasilkan angka keuntungan.</p></div> : <p className="stock-review-hint">Setelah selesai menghitung, tekan “Tinjau ringkasan” untuk melihat hasilnya sebelum catatan disimpan.</p>}
      <div className="form-footer stock-review-actions"><button className="button button-primary" onClick={() => { setReviewOpen(true); setNotice(''); }} disabled={completeRows.length === 0 || !expenseTotalSafe || Boolean(stockCalculation.error)}><Calculator size={16} /> Tinjau ringkasan</button><button className="button button-secondary" onClick={resetDraft}><RotateCcw size={16} /> Kosongkan form</button><button className="button button-disabled" disabled title="Backend penyimpanan belum diaktifkan"><Check size={16} /> Simpan catatan (belum aktif)</button></div>
    </section>
  </div>;
}

function ExpensePage() {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [source, setSource] = useState<'STORE' | 'PERSONAL' | 'UNKNOWN' | ''>('');
  const [date, setDate] = useState(jakartaDateValue);
  const amountValue = amount === '' ? null : Number(amount);
  const amountLabel = amountValue === null ? 'Belum diisi' : money(amountValue);
  const sourceLabel = source === 'STORE' ? 'Uang toko' : source === 'PERSONAL' ? 'Uang pribadi' : source === 'UNKNOWN' ? 'Belum diketahui' : 'Belum dipilih';
  return <div className="content-stack expense-page"><PageTitle eyebrow="CATAT BIAYA" title="Pengeluaran toko" description="Catat biaya yang benar-benar terjadi. Sistem akan memisahkan dampak biaya dan uang toko setelah aturan sumber uang dipastikan." />
    <Note tone="warning" title="Pratinjau — belum disimpan">Form ini membantu meninjau data yang akan dicatat. Penyimpanan transaksi belum aktif.</Note>
    <div className="expense-layout"><section className="panel expense-form-panel"><div className="panel-heading"><div><p className="eyebrow">KEJADIAN</p><h2>Detail pengeluaran</h2></div><span className="panel-heading-icon"><ReceiptText size={18} /></span></div><div className="form-body">
      <label className="field-label" htmlFor="expense-description">Untuk apa uang digunakan?</label><input id="expense-description" className="text-field" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={100} placeholder="Contoh: Beli gas" />
      <label className="field-label" htmlFor="expense-amount">Jumlah uang</label><div className="input-with-prefix"><span>Rp</span><input id="expense-amount" className="text-field" inputMode="numeric" value={amount ? new Intl.NumberFormat('id-ID').format(Number(amount)) : ''} onChange={(e) => setAmount(digitsOnly(e.target.value))} placeholder="0" /></div>
      <label className="field-label" htmlFor="expense-date">Tanggal kejadian</label><input id="expense-date" type="date" className="text-field" value={date} onChange={(e) => setDate(e.target.value)} />
      <fieldset className="source-fieldset"><legend className="field-label">Uang yang dipakai dari mana?</legend><p className="field-help">Pilih sesuai kejadian; belum ada pilihan otomatis.</p><div className="source-choice-list"><label className={`source-choice ${source === 'STORE' ? 'source-choice-selected' : ''}`}><input type="radio" name="expense-source" value="STORE" checked={source === 'STORE'} onChange={() => setSource('STORE')} /><span><strong>Uang toko</strong><small>Uang yang dipegang toko ikut berkurang.</small></span></label><label className={`source-choice ${source === 'PERSONAL' ? 'source-choice-selected' : ''}`}><input type="radio" name="expense-source" value="PERSONAL" checked={source === 'PERSONAL'} onChange={() => setSource('PERSONAL')} /><span><strong>Uang pribadi</strong><small>Biaya dicatat, kas toko tidak otomatis berkurang.</small></span></label><label className={`source-choice ${source === 'UNKNOWN' ? 'source-choice-selected' : ''}`}><input type="radio" name="expense-source" value="UNKNOWN" checked={source === 'UNKNOWN'} onChange={() => setSource('UNKNOWN')} /><span><strong>Belum tahu</strong><small>Catatan uang akan ditandai belum pasti.</small></span></label></div></fieldset>
      <div className="form-footer"><button className="button button-disabled" disabled><Check size={16} /> Simpan belum tersedia</button><span><ShieldCheck size={14} /> Tidak ada transaksi dibuat</span></div>
    </div></section>
      <aside className="panel expense-preview-panel"><div className="panel-heading"><div><p className="eyebrow">PRATINJAU</p><h2>Periksa catatan</h2></div><StatusPill tone="warn">Belum disimpan</StatusPill></div><div className="expense-preview-amount">{amountLabel}</div><div className="preview-stat"><span>Keterangan</span><strong>{description.trim() || 'Belum diisi'}</strong></div><div className="preview-stat"><span>Tanggal</span><strong>{date || 'Belum diisi'}</strong></div><div className="preview-stat"><span>Sumber uang</span><strong>{sourceLabel}</strong></div><div className="preview-callout"><Info size={16} /><p>Biaya dapat memengaruhi hasil usaha. Dampaknya pada uang toko bergantung pada sumber uang dan aturan transaksi yang disahkan.</p></div></aside></div>
  </div>;
}

function CashPage() {
  return <div className="content-stack"><PageTitle eyebrow="SERAH-TERIMA UANG" title="Setoran karyawan" description="Setoran adalah uang yang benar-benar diserahkan karyawan kepada owner. Setoran bukan penjualan dan bukan keuntungan baru." action={<button className="button button-disabled" disabled><Banknote size={16} /> Pencatatan belum aktif</button>} /><Note tone="warning" title="Belum ada catatan uang">Angka uang sengaja tidak dihitung ketika tidak ada transaksi terverifikasi.</Note><section className="metric-grid metric-grid-three">{[{ label: 'Uang toko seharusnya', value: '—', icon: Wallet }, { label: 'Total setoran aktual', value: '—', icon: Banknote }, { label: 'Selisih', value: '—', icon: ArrowDownRight }].map(({ label, value, icon: Icon }) => <article className="metric-card" key={label}><div className="metric-top"><span>{label}</span><span className="metric-icon"><Icon size={17} /></span></div><strong className="metric-value">{value}</strong><p>Menunggu catatan yang sah</p></article>)}</section><div className="two-column-grid"><section className="panel"><div className="panel-heading"><div><p className="eyebrow">UANG KELUAR</p><h2>Pengeluaran toko</h2></div></div><EmptyPanel icon={ReceiptText} title="Belum ada pengeluaran" description="Contohnya gas, plastik, es batu, atau sabun. Pencatatan belum diaktifkan." /></section><section className="panel"><div className="panel-heading"><div><p className="eyebrow">UANG MASUK</p><h2>Pendapatan lain</h2></div></div><EmptyPanel icon={Banknote} title="Belum ada pendapatan lain" description="Contohnya jasa seduh mi. Ini terpisah dari penjualan barang." /></section></div></div>;
}

function ReportsPage() {
  return <div className="content-stack"><PageTitle eyebrow="RINGKASAN USAHA" title="Laporan" description="Lihat penjualan, keuntungan, stok, pengeluaran, dan setoran per periode." /><Note title="Laporan mengikuti data yang dapat dipastikan">Bagian yang belum diketahui akan ditandai, bukan diam-diam dianggap nol atau dihitung seolah-olah pasti.</Note><EmptyPanel icon={FileChartColumn} title="Laporan belum tersedia" description="Laporan akan diaktifkan setelah pencatatan dan penyimpanan telah dibuat serta diuji." /></div>;
}

function AssistantPage({ enabled, onToggle, onSettings }: { enabled: boolean; onToggle: (next: boolean) => void; onSettings: () => void }) {
  return <div className="content-stack"><PageTitle eyebrow="FITUR OPSIONAL" title="Asisten" description="Direncanakan untuk menerima catatan dengan bahasa sehari-hari, dengan persetujuan sebelum data disimpan." /><section className="assistant-hero"><div className="assistant-icon"><Sparkles size={25} /></div><div className="assistant-copy"><StatusPill tone={enabled ? 'warn' : 'neutral'}>{enabled ? 'UI Asisten ON' : 'Asisten OFF'}</StatusPill><h2>{enabled ? 'Tampilan asisten aktif, koneksi AI belum ada.' : 'Aplikasi tetap berjalan tanpa AI.'}</h2><p>{enabled ? 'Sakelar ini hanya menampilkan panel asisten. Belum ada model AI yang dipanggil, tidak ada API key, dan tidak ada teks yang dikirim ke layanan luar.' : 'Sesuai rencana, pencatatan inti dapat dibangun dan diuji tanpa AI. Aktifkan tampilan asisten hanya saat kamu ingin meninjau rancangan fitur tersebut.'}</p><button className="button button-secondary" onClick={() => enabled ? onToggle(false) : onToggle(true)}>{enabled ? 'Matikan Asisten UI' : 'Aktifkan tampilan Asisten'} <ArrowRight size={15} /></button></div><div className="assistant-sparkline"><Sparkles size={68} strokeWidth={0.8} /></div></section>{enabled ? <section className="panel assistant-panel"><div className="panel-heading"><div><p className="eyebrow">PRATINJAU FITUR</p><h2>Catatan dengan bahasa sehari-hari</h2></div><StatusPill tone="off">Belum tersambung</StatusPill></div><div className="assistant-message"><span className="assistant-avatar"><Sparkles size={17} /></span><p><strong>Asisten TOKO SAKALA</strong><br />Koneksi AI belum diimplementasikan. Untuk sekarang, gunakan halaman Belanja dan Cek sisa untuk melihat rancangan alur yang tidak memerlukan AI.</p></div><div className="disabled-compose"><input disabled placeholder="AI belum terhubung — kolom ini belum aktif" /><button disabled className="button button-disabled" aria-label="Kirim pesan"><ArrowRight size={16} /></button></div><p className="field-help">Tidak ada API key atau integrasi Gemini di paket ini. ON/OFF di sini hanya mengatur preferensi UI.</p></section> : <EmptyPanel icon={Sparkles} title="Asisten sedang OFF" description="Fitur AI sengaja nonaktif secara default. Aktifkan tampilannya melalui Pengaturan kapan pun diperlukan." action={<button className="button button-secondary" onClick={onSettings}>Buka pengaturan <ArrowRight size={15} /></button>} />}<Note title="Prinsip keamanan AI">Saat fitur ini kelak terhubung, AI hanya boleh mengusulkan transaksi. Engine deterministik tetap menghitung, pengguna meninjau, dan server memvalidasi sebelum menyimpan.</Note></div>;
}

function HistoryPage() {
  return <div className="content-stack"><PageTitle eyebrow="JEJAK PERUBAHAN" title="Riwayat" description="Riwayat membantu melacak catatan yang dibuat, direvisi, dibatalkan, atau dikoreksi." /><Note tone="warning" title="Riwayat transaksi belum tersedia">Tidak ada catatan yang tersimpan. Setelah backend aktif, perubahan harus dapat dilacak dan tidak boleh mengubah sejarah secara diam-diam.</Note><EmptyPanel icon={Clock3} title="Belum ada riwayat" description="Riwayat akan muncul setelah ada data yang benar-benar berhasil disimpan." /></div>;
}

function SettingsPage({ enabled, onToggle, theme, onThemeChange }: { enabled: boolean; onToggle: (next: boolean) => void; theme: Theme; onThemeChange: (next: Theme) => void }) {
  return <div className="content-stack"><PageTitle eyebrow="PREFERENSI APLIKASI" title="Pengaturan" description="Atur tampilan dan fitur opsional. Preferensi disimpan di browser ini; data keuangan belum disimpan." />
    <section className="panel settings-panel theme-panel"><div className="panel-heading"><div><p className="eyebrow">TAMPILAN</p><h2>Tema aplikasi</h2></div><span className="panel-heading-icon"><Activity size={17} /></span></div><p className="field-help">Pilih tampilan yang nyaman. Pilihan ini hanya mengubah tampilan aplikasi.</p><div className="theme-choice-grid"><button type="button" className={`theme-choice ${theme === 'light' ? 'theme-choice-active' : ''}`} onClick={() => onThemeChange('light')} aria-pressed={theme === 'light'}><span className="theme-preview theme-preview-light"><span></span><span></span><span></span></span><strong>Terang</strong><small>Warm ivory · jelas di siang hari</small></button><button type="button" className={`theme-choice ${theme === 'dark' ? 'theme-choice-active' : ''}`} onClick={() => onThemeChange('dark')} aria-pressed={theme === 'dark'}><span className="theme-preview theme-preview-dark"><span></span><span></span><span></span></span><strong>Gelap</strong><small>Deep forest · nyaman di cahaya rendah</small></button></div></section><section className="panel settings-panel"><div className="panel-heading"><div><p className="eyebrow">FITUR OPSIONAL</p><h2>Asisten AI</h2></div><span className="panel-heading-icon"><Sparkles size={17} /></span></div><div className="setting-row"><div className="setting-copy"><div className="setting-title"><strong>Asisten AI</strong><StatusPill tone={enabled ? 'warn' : 'neutral'}>{enabled ? 'ON' : 'OFF'}</StatusPill></div><p>{enabled ? 'Tampilan asisten diaktifkan. Integrasi model masih belum dibuat.' : 'Nonaktif. Aplikasi inti tidak memerlukan AI untuk menjalankan alur dasar.'}</p></div><AiToggle enabled={enabled} onChange={onToggle} /></div><div className="setting-explainer"><Info size={17} /><div><strong>Yang berubah saat sakelar digeser</strong><p>Hanya tampilan panel asisten. Sakelar ON belum menghubungkan Gemini, tidak mengirim data ke luar aplikasi, dan tidak mengaktifkan API. Saat integrasi AI dibuat pada tahap berikutnya, perilaku ini harus ditinjau ulang dengan persetujuanmu.</p></div></div></section><section className="panel settings-panel"><div className="panel-heading"><div><p className="eyebrow">STATUS PROYEK</p><h2>Fondasi aplikasi</h2></div><span className="panel-heading-icon"><ShieldCheck size={17} /></span></div><div className="project-check-list"><ProjectCheck label="Antarmuka React responsif" state="Ada di starter" good /><ProjectCheck label="Engine pratinjau belanja awal" state="Ada; cakupan terbatas" good /><ProjectCheck label="Asisten AI" state={AI_INTEGRATION_CONNECTED ? 'Tersambung' : 'Belum tersambung'} /><ProjectCheck label="Simpan transaksi ke database" state="Belum aktif" /><ProjectCheck label="Backup dan pemulihan data toko" state="Belum diuji" /></div></section><Note tone="warning" title="Jangan masukkan data toko sebenarnya dulu">Sebelum pencatatan nyata, backend perlu menyimpan transaksi secara atomik, melakukan validasi server, menjaga riwayat append-only, serta lulus uji backup/pemulihan dan keamanan akses.</Note></div>;
}

function ProjectCheck({ label, state, good = false }: { label: string; state: string; good?: boolean }) {
  return <div className="project-check-row"><span className={`check-mark ${good ? 'check-mark-good' : ''}`}>{good ? <Check size={14} /> : <Clock3 size={14} />}</span><span>{label}</span><span className="project-check-state">{state}</span></div>;
}
