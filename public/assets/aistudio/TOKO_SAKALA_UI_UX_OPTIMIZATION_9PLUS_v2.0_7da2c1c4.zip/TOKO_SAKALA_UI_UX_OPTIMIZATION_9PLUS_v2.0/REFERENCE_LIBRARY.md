# TOKO SAKALA — Reference Library for Mobile UI/UX Refinement

**Dibuat:** 27 Oktober 2026  
**Kegunaan:** sumber prinsip yang dapat diverifikasi dan inspirasi visual. Referensi visual komunitas (Dribbble/Pinterest/Behance) adalah moodboard, bukan bukti usability. Utamakan dokumentasi resmi dan riset usability untuk keputusan perilaku.

## A. Prinsip produk dan layout

1. **Apple Human Interface Guidelines — Design Principles**  
   https://developer.apple.com/design/human-interface-guidelines/design-principles  
   Gunakan untuk: fokus pada tugas inti, keluar dari alur dengan mudah, pemulihan kesalahan, konsistensi, dan menghindari dekorasi yang mengganggu.

2. **Apple HIG — Layout (pembaruan September 2026)**  
   https://developer.apple.com/design/human-interface-guidelines/layout  
   Gunakan untuk: hierarki, penempatan informasi utama, kelompok elemen, adaptasi lintas layar, dan whitespace.

3. **Apple HIG — Writing**  
   https://developer.apple.com/design/human-interface-guidelines/writing  
   Gunakan untuk: label berorientasi tindakan, bahasa konsisten, mengutamakan kata yang jelas daripada kata kreatif.

4. **Apple HIG — Buttons**  
   https://developer.apple.com/design/human-interface-guidelines/buttons  
   Gunakan untuk: tombol jelas, affordance yang terlihat, hit area, dan state ditekan.

5. **Apple HIG — Sheets (pembaruan Maret 2026)**  
   https://developer.apple.com/design/human-interface-guidelines/sheets  
   Gunakan untuk: bottom sheet atau modal untuk tugas singkat yang terkait konteks, bukan wizard panjang.

6. **Apple HIG — Materials**  
   https://developer.apple.com/design/human-interface-guidelines/materials  
   Gunakan untuk: membedakan lapisan kontrol dari konten. Jangan menaruh efek glass di semua kartu data.

7. **Material Design 3 — Components and theming**  
   https://developer.android.com/develop/ui/compose/designsystems/material3  
   Gunakan untuk: hierarki tindakan, peran warna, komponen dengan state konsisten, dan palet tonal yang mempertimbangkan kontras.

8. **GitHub Primer Design System — Foundations**  
   https://primer.github.io/design/foundations/  
   Gunakan untuk: token warna, tipografi, layout responsif, komponen yang konsisten, dan pendekatan sistem desain yang dapat dipelihara.

9. **GitHub Primer — Product Foundations**  
   https://primer.style/product/getting-started/foundations/  
   Gunakan untuk: fondasi, konten produk, ikon, layout responsif, dan tipografi.

10. **Vercel Geist — Colors**  
    https://vercel.com/geist/colors  
    Gunakan untuk: pemisahan warna background, surface, border, text, dan status. Jangan menyalin palet secara mentah; adaptasikan pada Deep Teal/Warm Ivory.

11. **Vercel Geist — Typography**  
    https://vercel.com/geist/typography  
    Gunakan untuk: skala tipografi yang konsisten, line-height, dan bobot tulisan.

## B. Accessibility dan keterbacaan

12. **W3C — Web Content Accessibility Guidelines (WCAG) 2.2**  
    https://www.w3.org/TR/WCAG22/  
    Target minimum yang direkomendasikan: WCAG 2.2 AA untuk seluruh alur utama. Kontras teks normal umumnya minimal 4.5:1; teks besar minimal 3:1; komponen dan objek grafis penting minimal 3:1.

13. **W3C WAI — What's New in WCAG 2.2**  
    https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/  
    Gunakan untuk: fokus tidak tertutup, ukuran target, indikator fokus, dan mencegah interaksi mengandalkan drag saja.

14. **Android Developers — Accessibility**  
    https://developer.android.com/guide/topics/ui/accessibility/apps  
    Rekomendasi target sentuh Android setidaknya 48×48 dp. Untuk web mobile, gunakan target praktis 44–48 CSS px dan jarak yang memadai.

15. **Google Accessibility Help — Touch target size**  
    https://support.google.com/accessibility/android/answer/7101858  
    Gunakan untuk: mengecek ukuran tombol ikon, tombol hapus, filter, dan navigasi bawah.

16. **GitHub Primer — TextInput accessibility**  
    https://primer.style/product/components/text-input/accessibility/  
    Gunakan untuk: label yang jelas, helper text yang terhubung secara semantik, serta error yang tidak hanya dibedakan dengan warna.

17. **GOV.UK Design System — Text input**  
    https://design-system.service.gov.uk/components/text-input/  
    Gunakan untuk: label di atas input, hindari placeholder sebagai label, field prefix/suffix yang tidak menimpa teks, serta pesan kesalahan spesifik.

18. **GOV.UK Design System — Error message**  
    https://design-system.service.gov.uk/components/error-message/  
    Gunakan untuk: menjelaskan apa yang salah dan bagaimana memperbaikinya; jangan menghapus input yang sudah diisi ketika terjadi error.

19. **GOV.UK Design System — Headings**  
    https://design-system.service.gov.uk/styles/headings/  
    Gunakan untuk: sentence case, hierarki heading yang konsisten, dan ukuran teks mobile yang mudah dibaca.

20. **GOV.UK Design System — Components**  
    https://design-system.service.gov.uk/components/  
    Gunakan untuk: komponen sederhana dan pola validasi yang dapat diuji.

## C. Riset usability dan UX writing

21. **Nielsen Norman Group — Website Forms Usability: Top 10 Recommendations**  
    https://www.nngroup.com/articles/web-form-design/  
    Gunakan untuk: mengurangi field, mengelompokkan label dengan input, memakai satu kolom pada mobile, dan urutan input yang logis.

22. **Nielsen Norman Group — Mobile Input Checklist**  
    https://www.nngroup.com/articles/mobile-input-checklist/  
    Gunakan untuk: memeriksa setiap field mobile—apakah perlu, label terlihat, keyboard sesuai, default berguna, dan dapat dihitung oleh sistem.

23. **Nielsen Norman Group — Four Principles to Reduce Cognitive Load in Forms**  
    https://www.nngroup.com/articles/4-principles-reduce-cognitive-load/  
    Gunakan untuk: plain language, mengurangi pilihan, pola familiar, dan meminta informasi hanya ketika diperlukan.

24. **Nielsen Norman Group — UX Writing Study Guide (review Agustus 2026)**  
    https://www.nngroup.com/articles/ux-writing-study-guide/  
    Gunakan untuk: bahasa sederhana, ringkas, konsisten, dan sesuai konteks pengguna.

25. **Nielsen Norman Group — White Space in Form Design**  
    https://www.nngroup.com/articles/form-design-white-space/  
    Gunakan untuk: kedekatan label/input, pemisahan kelompok, dan alur pemindaian yang lebih jelas.

26. **Baymard Institute — Avoid Extensive Multicolumn Forms**  
    https://baymard.com/research-articles/avoid-multi-column-forms  
    Gunakan untuk: menghindari banyak kolom yang membuat pengguna salah membaca urutan. Pengecualian: field singkat yang memang saling terkait, misalnya jumlah dan unit.

27. **UCL — Interface Content**  
    https://www.ucl.ac.uk/brand-and-experience/experience/content/interface-content  
    Gunakan untuk: kalimat percakapan yang wajar, ringkas, satu gagasan per kalimat, dan istilah yang konsisten.

## D. Tren mobile 2026 yang relevan

28. **Framna — Mobile App Trends Report 2026: Experience (29 Mei 2026)**  
    https://framna.com/mobile-app-trends-report-2026/experience  
    Inti yang relevan: hierarki dan kepadatan informasi yang tepat lebih berpengaruh pada rasa mudah daripada polish visual sendirian.

29. **GMI Software — Mobile UI/UX Trends in 2026 (8 Juli 2026)**  
    https://gmi.software/blog/mobile-app-design-trends  
    Gunakan sebagai rangkuman tren industri, bukan standar normatif. Terapkan prinsipnya hanya bila benar-benar mengurangi gesekan.

30. **Designity — UI/UX Design Trends 2026 (11 Juli 2026)**  
    https://www.designity.com/blog/ui-ux-design-trends  
    Gunakan sebagai konteks tren eksploratif; jangan menerapkan ornamen hanya karena sedang tren.

## E. Inspirasi visual khusus inventory dan keuangan

31. **Dribbble — Inventory Management Mobile App UI (27 Oktober 2026 hasil pencarian, konsep inspirasi)**  
    https://dribbble.com/shots/27711713-Inventory-Management-Mobile-App-UI-Dashboard-Stock-Tracking  
    Perhatikan hierarki daftar, filter, pencarian, dan status stok. Abaikan elemen gudang/logistik yang tidak relevan dengan warung.

32. **Dribbble — Inventory Management Mobile App UI**  
    https://dribbble.com/shots/27287547-Inventory-Management-Mobile-App-UI  
    Perhatikan pembagian list, status stok, pencarian, dan pemakaian warna netral. Hanya moodboard.

33. **Dribbble — Inventory Mobile App**  
    https://dribbble.com/shots/25745910-Inventory-Mobile-APP  
    Perhatikan pola list produk dan bottom navigation, bukan warna/branding literal.

34. **Dribbble — Finance Flow Dashboard Overview**  
    https://dribbble.com/shots/26376521-Finance-Flow-Modern-Budget-Expense-Tracking-Dashboard  
    Perhatikan pengelompokan ringkasan metrik dan grafik. Gunakan hanya bila grafik menjawab pertanyaan toko.

35. **Kyte — Stock Control**  
    https://www.kyte.com.br/gerenciar/controle-de-estoque  
    Referensi produk nyata untuk pengelolaan stok sederhana. Evaluasi perilaku yang relevan, jangan menambah POS ke scope TOKO SAKALA.

36. **Pinterest — Mobile inventory UI search (moodboard)**  
    https://www.pinterest.com/search/pins/?q=mobile%20inventory%20management%20UI  
    Gunakan hanya sebagai eksplorasi komposisi dan warna; validasi pola terhadap referensi resmi.

37. **Behance — Inventory management mobile app search (moodboard)**  
    https://www.behance.net/search/projects?search=inventory%20management%20mobile%20app%20ui  
    Gunakan sebagai eksplorasi visual; jangan anggap desain konsep sebagai bukti usability.

38. **GitHub Primer repository**  
    https://github.com/primer  
    Gunakan untuk melihat implementasi sistem desain open-source, token, komponen dan pola aksesibilitas.

## Cara memilih referensi

- **Perilaku/aksesibilitas:** WCAG 2.2, Apple HIG, Android, Primer, GOV.UK, NN/G, Baymard.
- **Sistem desain:** Primer, Material 3, Geist.
- **Moodboard:** Dribbble, Pinterest, Behance. Tidak menyalin mentah dan tidak mengalahkan aturan bisnis TOKO SAKALA.
- Hindari tren yang mengurangi keterbacaan: glass/blur di belakang teks, warna pastel dengan kontras rendah, gradient besar, animasi berlebihan, dan kartu dekoratif yang menyembunyikan tugas utama.
