# TOKO SAKALA — Mobile UI/UX Optimization Pack v2.0

Paket ini berisi spesifikasi penyempurnaan UI/UX mobile dan prompt implementasi untuk ditempel ke Google AI Studio Build pada repository TOKO SAKALA yang sekarang.

## Isi

1. `TOKO_SAKALA_MOBILE_UI_UX_OPTIMIZATION_9PLUS_v2.0.md` — master brief: hasil audit video, prinsip desain, per halaman, bahasa UI, token warna, accessibility, motion, pengujian, dan rubrik target 9+.
2. `GOOGLE_AI_STUDIO_EXECUTION_PROMPT_v2.0.md` — prompt kerja untuk meminta AI Studio mengaudit source code yang ada dan menerapkan perbaikan langsung.
3. `REFERENCE_LIBRARY.md` — referensi resmi, riset usability, dan referensi visual inspiratif dengan catatan cara menggunakannya.

## Cara pakai yang aman

1. Push perubahan terbaru aplikasi ke GitHub sebelum melakukan eksperimen.
2. Buka repository TOKO SAKALA yang sama di Google AI Studio Build.
3. Tempelkan seluruh `GOOGLE_AI_STUDIO_EXECUTION_PROMPT_v2.0.md`.
4. Unggah/sertakan `TOKO_SAKALA_MOBILE_UI_UX_OPTIMIZATION_9PLUS_v2.0.md` dan `REFERENCE_LIBRARY.md` jika AI Studio meminta konteks tambahan.
5. Minta AI Studio membuat perubahan pada source code yang ada, bukan hanya menulis rencana atau membuat mockup.
6. Verifikasi setiap layar pada lebar 360, 390, 430 px dan tablet/desktop sebelum commit dan Push origin.

## Prinsip penting

- Target 9+ adalah target acceptance, bukan skor yang boleh diklaim sebelum perubahan diuji.
- Jangan mengganti perhitungan uang, arti setoran karyawan ke owner, atau histori transaksi demi mempercantik UI.
- Istilah `Keuntungan Jual` merupakan istilah yang dipakai pengguna untuk nilai penjualan jika semua barang terjual sebelum modal dikurangi. Pertahankan istilahnya dengan keterangan penjelas; jangan menyebutnya laba.
- Setoran adalah penyerahan uang dari karyawan kepada owner, bukan setoran bank dan bukan pendapatan/laba baru.
- Asisten AI tetap OFF secara default dan semua alur utama tetap berjalan tanpa model AI.
- Jangan menambahkan dependency berbayar, login/cloud, atau fitur baru di luar kebutuhan audit ini.
- Tidak boleh menyatakan build, tes, atau WCAG lulus jika belum benar-benar dijalankan.
