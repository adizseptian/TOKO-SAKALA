# GOOGLE AI STUDIO BUILD PROMPT — TOKO SAKALA UI/UX OPTIMIZATION 9+ v2.0

Kamu bekerja di repository TOKO SAKALA yang SUDAH ADA. Tugasmu adalah MENGAUDIT DAN MENGUBAH SOURCE CODE YANG ADA secara nyata, bukan hanya menjawab dengan saran, membuat desain konseptual, atau membuat aplikasi pengganti.

Baca `TOKO_SAKALA_MOBILE_UI_UX_OPTIMIZATION_9PLUS_v2.0.md` dan `REFERENCE_LIBRARY.md` terlebih dahulu jika tersedia di repository/attachment. Gunakan dokumen tersebut sebagai acceptance specification. Jika dokumen tidak tersedia, ikuti instruksi lengkap di bawah ini.

## 0. Aturan mutlak

1. Jangan membuat repository/proyek baru. Jangan menghapus lalu membuat ulang aplikasi.
2. Jangan mengganti stack yang berjalan, mengubah konfigurasi besar, atau menambahkan dependensi baru sebelum memeriksa package.json. Gunakan library yang sudah ada jika mampu menyelesaikan tugas.
3. Jangan menghapus fitur atau menimpa kerja yang sudah ada. Pertahankan seluruh fungsi yang tidak terkait dengan masalah UI/UX ini.
4. Jangan mengubah rumus keuangan, struktur event, makna setoran, aturan periode, cara penyimpanan, atau histori demi menyederhanakan UI. Jika menemukan inkonsistensi, catat, buat tes regresi, dan minta audit di lapisan domain yang sesuai; jangan melakukan refactor finansial diam-diam.
5. `Keuntungan Jual` adalah istilah pemilik untuk **nilai penjualan jika semua barang terjual, sebelum dikurangi modal**. Pertahankan istilah ini dengan helper: `Nilai penjualan jika semua barang terjual — belum dikurangi modal.` Jangan menyebutnya laba.
6. Setoran berarti karyawan menyerahkan uang kepada owner. `Uang diterima owner` bukan penjualan/laba baru, dan pembelian dari uang pribadi owner tidak otomatis mengurangi uang yang dipegang karyawan.
7. Asisten AI tetap OFF sebagai default. Alur utama harus bekerja tanpa panggilan model. Jangan memalsukan hasil AI atau menambahkan API key.
8. Jangan mengklaim build/tests/accessibility lulus jika tidak benar-benar dijalankan. Jangan memberi semua komponen skor 9+ tanpa bukti acceptance.
9. Jangan menggunakan warna violet sebagai brand, tidak ada low-contrast pastel untuk teks kecil, tidak ada animasi berlebihan, tidak ada glass/blur di belakang teks/data, dan tidak ada dekorasi yang membuat angka lebih sulit dibaca.
10. Semua teks antarmuka dalam bahasa Indonesia sehari-hari, ringkas, konsisten, dan berorientasi tindakan.

## 1. Mulai dengan audit source code

Sebelum mengubah file:

- Periksa struktur folder, package manager, versi React/framework, global CSS/tokens, komponen layout, screens, state/data layer, form, dan tests.
- Temukan semua komponen header, bottom navigation, drawer, cards, product table/list, purchase form, stock-check form, owner remittance/deposit, reports, toast, modal, badge, alert, empty/error/loading states, theme toggle dan currency inputs.
- Catat file yang mengatur Light/Dark Mode dan warna semantik.
- Temukan apakah ada dua definisi token atau komponen yang saling bertentangan.
- Temukan source of truth untuk hitungan uang; jangan membuat formula baru di komponen.
- Jalankan perintah yang tersedia untuk build/lint/typecheck/test sebelum mengubah kode, jika lingkungan memungkinkan. Catat baseline dan error yang sudah ada.
- Buat checklist file/change map terlebih dahulu secara internal lalu lanjutkan implementasi; jangan berhenti hanya pada audit.

## 2. Prioritas implementasi

Kerjakan urutan ini; jangan memulai dari animasi:

### P0 — Keterbacaan dan kepercayaan finansial

- Perbaiki warna Light Mode agar benar-benar terang, hangat, dan kontras. Jangan cukup mengubah background; audit text, secondary text, placeholders, borders, inputs, table rows, badges, warning/error banners, disabled/focus/hover states.
- Pastikan seluruh badge/alert menggunakan pasangan background + foreground yang kontras dan didukung ikon + label.
- Perbaiki currency input: `Rp` berada di prefix slot terpisah, tidak overlap dengan angka/caret; input tetap dapat mengetik, memilih, menempel, dan menghapus angka tanpa bug.
- Search field: ikon search tidak menumpuk ke teks/caret. Jika ikon hanya dekoratif, bukan elemen interaktif; tampilkan tombol clear hanya saat ada teks. Ikon tidak boleh membuat fokus/label hilang atau mengganggu input.
- Audit semua label `Keuntungan Jual`, `Laba kotor`, `Laba bersih`, `Nilai modal stok`, `Uang yang perlu diserahkan`, `Uang diterima owner`, dan `Selisih setoran` agar maknanya tidak tertukar.
- Audit angka negatif pada Setoran. Jangan hanya mengubah warna atau label: pastikan pengguna mendapat penjelasan yang benar berdasarkan sumber perhitungan. Jika penyebab belum dapat ditentukan, gunakan bahasa netral `Perlu diperiksa` dan jangan menyimpulkan uang hilang.
- Hilangkan error yang muncul sebelum pengguna berinteraksi atau mengirim data; validasi hanya muncul untuk row/field relevan.

### P0 — Layout mobile untuk tugas inti

Wajib uji minimal lebar 360, 390, dan 430 CSS px.

- Header: pada mobile sembunyikan breadcrumb panjang, tampilkan judul utuh, maksimal satu aksi kontekstual di kanan, tanpa truncation `Ringkasan T...` atau `Laporan Ke...`.
- Bottom navigation: hanya `Beranda`, `Belanja`, `Cek Sisa`, `Setoran`, `Menu`. Pastikan active state jelas. Saat virtual keyboard terbuka, sembunyikan/reduksi nav tanpa menutup CTA atau field.
- Drawer: samakan nama menu dan page title; ringkas footer dan hapus counter tidak penting yang memakan tinggi.
- Barang: gunakan list-first/card row di mobile; jangan menekan tabel desktop ke layar kecil. Tidak boleh ada horizontal scroll untuk nama, stok, dan harga. Desktop masih boleh memakai tabel lengkap.
- Cek Sisa: daftar multi-barang dengan satu input besar per row `Sisa sekarang`. Tidak ada tabel enam kolom dan tidak ada horizontal scroll. Pengguna dapat mengisi banyak item pada satu halaman, berpindah input memakai tombol Next/Enter, dan menyimpan sekali.
- Jangan memberikan error pada row yang belum disentuh. Untuk `sisa > tersedia`, tampilkan error hanya di row itu, pertahankan input, dan jelaskan cara memperbaikinya.
- Belanja: form satu kolom pada mobile. Dua kolom hanya untuk field pendek yang secara makna terkait. Autocomplete data barang, isi kemasan, dan harga yang sudah diketahui; tetap izinkan perubahan yang eksplisit.
- Tetap gunakan preview dari calculation engine yang sama. Jangan menduplikasi rumus di UI.
- Sticky bottom action tidak boleh menutupi field yang fokus, error, toast, maupun keyboard.

### P1 — Kurangi beban informasi dan bahasa

- Beranda: status/aksi berikutnya di atas; metrik penting maksimal 4 dan lebih ringkas; aktivitas terakhir maksimal 3; empat langkah panduan diringkas menjadi satu strip yang bisa diperluas. Jangan meletakkan empat kartu panduan besar di layar awal.
- Katalog: search, tombol `+ Barang`, filter `Semua / Stok ada / Habis`. Sort/layout/filter lanjut ke menu ringkas.
- Belanja: helper satu kalimat; otomatisasi angka yang sudah diketahui; tidak menampilkan penjelasan teknis panjang.
- Setoran: tampilkan `Uang yang perlu diserahkan`, `Uang diterima owner`, dan `Selisih setoran` secara terpisah; periode jelas; status dan tindakan selanjutnya mudah dipahami.
- Laporan: buang paragraf panjang sebagai banner; ubah menjadi judul singkat + penjelasan + `Lihat perhitungan`. Ekspor dalam satu menu `Ekspor laporan` dengan PDF, Excel, CSV, dan Backup JSON yang tersedia menurut fungsi sebenarnya.
- Riwayat: gunakan list/timeline ringkas; aksi koreksi/batal diberi label dan mempertahankan audit trail.
- Pengaturan: kelompokkan Tampilan, Cara pencatatan, Data & backup, Tentang aplikasi; `Kosongkan semua data` menjadi tindakan berisiko dan perlu konfirmasi eksplisit.
- Samakan istilah di navigation, heading, tombol, badge, toast, laporan, dan dialog.

### P2 — Sistem visual premium

- Terapkan design tokens semantik yang sudah ada; jika belum ada atau duplikat, rapikan satu sumber token.
- Arah visual: `Warm Editorial Utility × Deep Teal Precision`; brand Deep Teal + Warm Ivory, tanpa violet.
- Light Mode dan Dark Mode dibuat setara kualitasnya, bukan inverse otomatis. Pastikan card surfaces memiliki layer yang terlihat tetapi tidak kompetitif.
- Standarkan tipografi, line-height, font weight, tabular numerals untuk rupiah, spasi berbasis 4/8, radius, border, shadows, icon sizes, dan state focus/hover/pressed.
- Gunakan satu icon family. Icon-only buttons mempunyai accessible name.
- Motion singkat dan bertujuan; hormati `prefers-reduced-motion`. Jangan memasang library baru jika Motion sudah terpasang.

## 3. Bahasa aplikasi yang harus digunakan

Utamakan kata sehari-hari. Teks berorientasi tindakan, tidak bertele-tele, dan tidak memarahi pengguna.

| Konteks | Copy target |
|---|---|
| Deskripsi Beranda | `Lihat stok, hasil toko, dan setoran karyawan.` |
| Tombol stok | `Cek sisa` |
| Input jumlah | `Sisa sekarang` |
| Empty barang | `Belum ada barang. Tambahkan barang pertama untuk mulai mencatat belanja.` |
| Filter kosong | `Tidak ada barang pada pilihan ini.` CTA `Tampilkan semua barang`. |
| Input kosong | `Masukkan jumlah sisa barang.` |
| Stok berlebih | `Sisa melebihi stok yang tercatat. Periksa belanja yang belum dicatat atau hitung kembali.` |
| Modal tidak diketahui | `Modal barang ini belum diketahui. Hasil untung belum lengkap.` |
| Belum tersimpan | `Belum disimpan — periksa angka sebelum menyimpan.` |
| Save sukses | `Tersimpan. 8 barang diperbarui.` (nilai dinamis dari hasil nyata) |
| Koneksi gagal | `Belum tersambung. Data belum disimpan. Periksa koneksi, lalu coba lagi.` |
| Setoran cocok | `Setoran cocok dengan catatan.` |
| Setoran tak pasti | `Nominal terlihat cocok, tetapi masih ada data yang belum pasti.` |
| Keuntungan Jual | `Keuntungan Jual` + `Nilai penjualan jika semua barang terjual — belum dikurangi modal.` |
| Setoran karyawan | `Uang diterima owner` |

Jangan hardcode jumlah demo ke pesan runtime. Contoh teks di atas adalah pola; isi harus bersumber dari data aktual.

## 4. Warna dan aksesibilitas

Gunakan token semantik dan uji setiap pasangan text/background. Nilai baseline yang bisa disesuaikan setelah contrast testing:

**Light:** bg `#F7F7F2`, surface `#FFFFFF`, surface-2 `#EEF3EF`, surface-3 `#E3EBE5`, text `#152521`, secondary `#40564E`, muted `#566861`, border `#C8D5CD`, brand `#176B61`, accent `#B08D3C`.

**Dark:** bg `#0D1717`, surface `#172321`, surface-2 `#1D302C`, surface-3 `#263B35`, text `#F3F6F2`, secondary `#BDC9C2`, muted `#A0B0A7`, border `#3A4E46`, accent `#D0B16D`; brand teal `#55B8A5` hanya digunakan pada pasangan yang lolos contrast.

- Target WCAG 2.2 AA; teks normal 4.5:1, teks besar 3:1, komponen/grafik penting 3:1.
- Status harus memiliki label dan icon, bukan warna saja.
- Target sentuh 44–48 CSS px.
- Focus visible, input label visible, `aria-describedby` untuk helper/error, modal focus behavior, no keyboard trap yang tidak sesuai.

## 5. State wajib

Pastikan loading, empty, error input, error layanan, success, saving/pending, dan uncertain state ada pada halaman yang relevan. Jangan membuat state visual statis yang tidak terhubung ke kondisi nyata. Jangan pernah menampilkan toast sukses saat save gagal.

- Pertahankan nilai form jika error.
- Loading skeleton mengikuti struktur konten.
- Toast tidak menutupi field utama/keyboard/CTA.
- Reduced motion tidak memakai perpindahan besar.
- Error harus menjelaskan apa yang salah dan cara memperbaikinya.

## 6. Export/report UX

- Gunakan satu action `Ekspor laporan`.
- PDF, XLSX, CSV, dan JSON memiliki peran yang jelas; JSON disebut `Backup data`, bukan laporan.
- Jangan buat tombol untuk fitur yang belum benar-benar bekerja. Jika belum implementable pada stack, nyatakan `Belum tersedia` daripada pura-pura.
- Uji file yang dihasilkan dapat dibuka, periode/angka sama dengan layar, nilai belum pasti ditandai, dan tidak ada kolom terpotong.

## 7. Test dan verifikasi setelah perubahan

Jalankan sesuai package scripts proyek: build, lint, typecheck, unit tests, E2E jika ada. Uji semua halaman di 360/390/430/768/1024/1440 px, Light/Dark, dengan keyboard, modal, toast, error, empty, loading. Jalankan contrast checker dan automated accessibility tests jika tool tersedia.

Wajib uji contoh bisnis berikut tanpa mengubah formula:
- 2 dus × 24 = 48 pcs.
- Harga beli Rp96.000/dus = total belanja Rp192.000.
- Harga jual Rp7.000/pcs = Keuntungan Jual Rp336.000 dengan caption belum dikurangi modal.
- Sisa 10 pcs dari 48, tanpa pengurangan lain, berarti 38 terjual.
- Penjualan Rp266.000; modal barang terjual Rp152.000; laba kotor Rp114.000 jika modal/unit konsisten Rp4.000.
- Pengeluaran Rp20.000 (bila sesuai klasifikasi bisnis) → laba bersih Rp94.000.
- Setoran dari karyawan kepada owner tidak menambah laba.
- Pembelian yang dibayar dengan uang pribadi owner tidak mengurangi uang yang dipegang karyawan.
- Data modal belum diketahui tidak boleh disebut laba pasti.
- Sisa > tersedia tidak boleh menghasilkan penjualan negatif.

Jika source code atau test fixture saat ini berbeda, jangan menulis ulang angka ke UI. Cocokkan dengan spesifikasi bisnis dan tunjukkan konflik sebagai temuan.

## 8. Urutan eksekusi

1. Audit source + baseline tests.
2. P0: contrast/theme, currency inputs, search, bahasa/angka setoran.
3. P0: mobile list Katalog dan Cek Sisa; keyboard/CTA/bottom nav.
4. P1: ringkas Beranda, Belanja, Laporan, Riwayat, Pengaturan.
5. P2: tokens, iconography, states, motion polish.
6. Regression/accessibility/performance tests.
7. Buat tabel nilai heuristik sebelum/sesudah. Skor ≥9 hanya bila acceptance terbukti; item yang tidak diuji ditandai `Belum diverifikasi`.

## 9. Laporan final yang harus kamu berikan

Setelah implementasi, berikan:
- Ringkasan perubahan nyata; bukan hanya rencana.
- Daftar file yang diubah.
- Daftar perbaikan per layar dan microcopy.
- Hasil build/lint/typecheck/test dengan hasil sebenarnya.
- Daftar viewport/tema yang diverifikasi dan screenshot jika memungkinkan.
- Tabel audit skor aspek dan bukti setiap skor ≥9.
- Bug atau risiko yang tersisa.
- Jelaskan jika ada bagian yang tidak dapat diselesaikan.

Mulai sekarang dengan membaca source dan menerapkan perubahan. Jangan berhenti pada laporan rekomendasi. Jangan mengklaim aplikasi sempurna atau semua skor 9+ jika belum ada bukti pengujian.
