# TOKO SAKALA — Mobile UI/UX Optimization Master v2.0

**Tanggal:** 27 Oktober 2026  
**Sumber audit:** rekaman `Screen_Recording_20261027_071615_Chrome.mp4` (±2 menit 55 detik), audit mobile v1.0, dan keputusan produk TOKO SAKALA yang telah dibahas.  
**Status:** Target specification / belum berarti implementasi sudah lulus.  
**Target:** setiap elemen dan alur utama mencapai penilaian heuristik 9+/10 setelah implementasi serta verifikasi.

> **Prinsip produk:** Jangan membuat pengguna memahami sistem. Buat sistem yang memahami pengguna.
>
> **Prinsip desain:** Desain fungsi, struktur, hierarki, lalu keindahan. Jangan mengorbankan informasi untuk dekorasi.

---

## 0. Cara menggunakan dokumen ini

Dokumen ini adalah brief utama untuk mengoptimalkan repository TOKO SAKALA yang sedang berjalan. Dokumen ini bukan izin untuk membuat aplikasi baru dari nol, mengganti business logic, atau menimpa source code yang lebih baru.

Setiap rekomendasi dibagi menjadi:
- **P0 — wajib:** hambatan tugas, keterbacaan penting, makna uang/setoran, dan integritas data.
- **P1 — pengalaman:** pengurangan klik, bahasa, alur formulir, responsivitas, empty/error/loading state.
- **P2 — polish:** konsistensi detail, gerak, elevasi, ikon, dan sentuhan premium.

**Target 9+ bukan angka dekoratif.** Komponen baru boleh disebut lulus jika acceptance criteria di dokumen ini sudah dipenuhi dan dibuktikan dengan pengujian. Jangan memberi skor final berdasarkan tangkapan layar statis saja.

## 1. Keputusan produk yang tidak boleh berubah

1. TOKO SAKALA adalah aplikasi pencatatan toko yang sederhana bagi pemilik/operator; sistem menghitung dan memeriksa di belakang layar.
2. Prioritas UX: akurasi angka → kemudahan → hierarki → aksesibilitas → ketenangan visual → motion/dekorasi.
3. Pengguna mencatat kejadian: belanja barang, cek sisa, barang rusak, barang dipakai, pengeluaran, pendapatan lain, dan setoran karyawan kepada owner.
4. **“Keuntungan Jual” adalah istilah pengguna untuk total uang penjualan jika seluruh barang terjual, sebelum dikurangi modal.** Jangan memperlakukannya sebagai laba. Untuk menghindari salah paham, tampilkan label tersebut beserta keterangan: `Nilai penjualan jika semua barang terjual — belum dikurangi modal.`
5. Laba kotor = penjualan yang terhitung − modal barang terjual. Laba bersih = laba kotor + pendapatan lain − biaya/rugi yang menurut aturan bisnis mengurangi hasil. Jangan menyamakan penjualan, laba, saldo kas, dan setoran.
6. **Setoran adalah uang dari karyawan kepada owner.** Uang yang diterima owner dicatat sebagai penerimaan setoran/serah-terima, bukan penjualan atau laba baru. Selisih harus ditampilkan netral dan dapat dijelaskan.
7. Belanja yang dibayar dari uang pribadi owner tidak otomatis mengurangi uang yang dipegang karyawan. Sumber uang tiap kejadian harus eksplisit/tercatat.
8. Sisa barang adalah input pengguna; jumlah terjual adalah hasil sistem hanya bila stok tersedia dan pengurangan nonpenjualan dapat dipastikan.
9. Barang rusak, barang dipakai, dan pengurangan yang tidak diketahui penyebabnya merupakan jenis kejadian terpisah, bukan otomatis penjualan.
10. Modal tidak diketahui tetap tidak diketahui; jangan mengarang nilai modal atau laba pasti.
11. Harga beli, harga jual, isi kemasan, dan kejadian terdahulu harus memiliki histori; perubahan baru tidak boleh mengubah sejarah diam-diam.
12. AI OFF secara default dan alur inti harus berjalan tanpa AI. Mode ON yang belum terhubung model tidak boleh berpura-pura melakukan AI.
13. Preview dan hasil penyimpanan harus menggunakan aturan hitung yang sama. UI tidak boleh memuat rumus keuangan duplikat.
14. Ekspor PDF/XLSX/CSV/JSON harus merepresentasikan sumber perhitungan yang sama, termasuk penanda nilai belum pasti.

## 2. Hasil audit video — kesimpulan kritis

Nilai berikut berasal dari audit heuristik rekaman, bukan hasil pengujian langsung kepada pengguna. Angka awal tidak boleh dianggap metrik universal.

| Aspek | Baseline heuristik | Target acceptance |
|---|---:|---:|
| Kerapian visual | 6.5 | ≥9.0 |
| Tugas harian di mobile | 5.0 | ≥9.0 |
| Light Mode | 3.5 | ≥9.0 |
| Dark Mode | 6.0 | ≥9.0 |
| Navigasi mobile | 6.0 | ≥9.0 |
| Kejelasan angka uang | 4.5 | ≥9.0 setelah audit rumus + copy |
| Form mobile | 5.0 | ≥9.0 |
| Kesan premium | 6.0 | ≥9.0 tanpa mengurangi keterbacaan |

### Masalah yang terlihat

- Judul header terpotong pada ponsel karena hamburger, breadcrumb, judul, bantuan, toggle tema, dan aksi global berdesakan.
- Beranda memakai terlalu banyak kartu dan instruksi. Tombol aksi bisa jatuh terpisah di baris baru.
- Katalog menumpuk beberapa kartu statistik sebelum pencarian, lalu tabel desktop dipaksa masuk ke lebar mobile. Nama barang patah menjadi banyak baris dan tabel perlu digeser horizontal.
- Form Belanja memakai kelompok field yang terlalu rapat untuk lebar ponsel; keyboard mengurangi area kerja, sementara kontrol navigasi masih menghabiskan ruang.
- Cek Sisa Fisik mengharuskan pengguna menggeser tabel, padahal ini termasuk aktivitas terpenting dan paling sering dilakukan.
- Error/alert kuning sangat samar di Light Mode; beberapa badge dan teks sekunder tidak cukup kontras.
- Setoran memperlihatkan angka negatif yang dapat disalahartikan sebagai kekurangan setoran atau uang hilang, tanpa mengomunikasikan dasar hitung/waktu checkpoint secara cukup jelas.
- Halaman Laporan memakai banner penjelasan panjang dan terlalu kuat secara visual dibandingkan angka serta tindakan ekspor.
- Drawer memiliki footer besar berisi slogan/angka item yang mengurangi ruang daftar navigasi.
- Beberapa kalimat teknis atau berulang memakan ruang tanpa membantu pengguna menyelesaikan tugas.
- Video tidak cukup membuktikan seluruh state network, save, toast, keyboard accessibility, atau backup berfungsi; semuanya wajib diuji di source code.

## 3. Arah desain modern dan premium untuk 2026

**Arah visual:** `Warm Editorial Utility × Deep Teal Precision`. Modern dan tenang, bukan futuristik dekoratif.

### Adopsi yang dipilih
- Hierarki informasi kuat dan kepadatan yang disengaja.
- Light Mode sebagai pengalaman yang sungguh dirancang, bukan inversi warna Dark Mode.
- Kartu lebih sedikit; panel netral, border halus, satu aksen brand yang terukur.
- List-first untuk produk pada mobile, bukan tabel desktop yang mengecil.
- Contextual bottom sheet/modal untuk tugas singkat; jangan membuat wizard berlapis jika satu layar sudah cukup.
- Empty/error/success states spesifik dan membantu pengguna pulih dari kesalahan.
- Motion kecil dan bertujuan: memberi feedback, menjaga kontinuitas, mengisyaratkan perubahan state.
- Token semantik dan komponen terpusat supaya Light/Dark konsisten.
- Format angka yang stabil, align kanan, angka tabular, dan label satuan jelas.

### Jangan ikut tren secara membabi buta
- Jangan menerapkan glassmorphism/Liquid Glass pada kartu angka atau tabel; blur tidak boleh mengurangi kontras.
- Jangan memberi gradient pada setiap kartu, glow besar, shadow berat, atau latar gradasi yang mengganggu angka.
- Jangan menggunakan banyak warna untuk membedakan kategori jika label/arti tidak jelas.
- Jangan menambahkan grafik ke Beranda hanya agar terlihat seperti dashboard SaaS.
- Jangan menambah fitur AI, scan, barcode, POS, atau prediksi hanya demi kesan modern.
- Jangan menggunakan icon-only action untuk tugas yang maknanya belum universal.
- Jangan memindahkan tombol hanya demi simetri bila itu merusak familiaritas.

## 4. Rubrik nilai 9+ yang dapat diaudit

Beri skor 0–10 per aspek **setelah** implementasi. Nilai 9 atau lebih memerlukan bukti di kolom acceptance; tampilan cantik saja tidak cukup.

| Dimensi | Apa yang diuji untuk nilai 9+ |
|---|---|
| 1. Bahasa | Label, bantuan, dan error dipahami sekali baca oleh pengguna non-akuntansi; istilah konsisten; tanpa instruksi berulang. |
| 2. Navigasi | Pengguna tahu lokasi dan aksi utama; active state konsisten; menu tak tumpang tindih dengan keyboard. |
| 3. Hierarki | Tujuan halaman, angka utama, dan aksi pertama jelas dalam 3 detik; elemen dekoratif tidak bersaing. |
| 4. Mobile layout | Tidak ada overflow horizontal pada 360/390/430 px untuk tugas inti; tidak ada teks terpotong. |
| 5. Tap target | Tombol utama dan kontrol sentuh berukuran memadai, target praktis 44–48 CSS px; tidak terlalu rapat. |
| 6. Light Mode | Teks penting, input, badge, error, border, dan status dapat terbaca; kontras diukur, bukan ditebak. |
| 7. Dark Mode | Kontras kuat tetapi tidak menyilaukan; layer dapat dibedakan; warna status tetap konsisten. |
| 8. Form | Label terlihat di atas field; keyboard sesuai; nilai terisi tidak hilang; default dan hitung otomatis digunakan bila aman. |
| 9. Cek Sisa | Semua produk dapat dicatat tanpa horizontal scroll; pengguna tidak harus buka form per produk; nilai terhitung jelas. |
| 10. Belanja | Unit kemasan, isi, jumlah, modal, harga jual, dan nilai penjualan potensial tidak tertukar; preview langsung. |
| 11. Setoran | Istilah employee → owner jelas; angka negatif tidak dibiarkan tanpa penjelasan; setoran tidak dianggap laba. |
| 12. Validasi | Hanya muncul saat relevan; menjelaskan bagian yang salah dan cara membetulkan; input tidak terhapus. |
| 13. Feedback | Loading, empty, error, success, dan unsaved state tepat; tidak ada fake-success. |
| 14. Riwayat | Pengguna mengerti kapan dan apa yang berubah; koreksi/void tidak meniadakan audit trail. |
| 15. Laporan/export | Output dapat dibaca/cetak; periode, satuan, status ketidakpastian, subtotal dan halaman benar. |
| 16. Accessibility | WCAG 2.2 AA diupayakan untuk seluruh alur utama; keyboard/focus/screen-reader labels diuji. |
| 17. Motion | Gerak halus, singkat, tidak menunda tugas, dan menghormati `prefers-reduced-motion`. |
| 18. Performa | Tidak ada input lag nyata, layout shift yang mengganggu, atau loader palsu; data/rumus benar. |
| 19. Konsistensi | Token, font, radius, spasi, status, label, dan perilaku komponen konsisten di semua halaman. |
| 20. Trust | Nominal selalu memiliki konteks/periode; belum pasti ditandai; tidak mengarang data atau menyembunyikan error. |

### Cara menghitung skor

- Nilai visual/heuristik 1–10 diberikan setelah review implementasi.
- Aspek integritas uang dan keamanan bersifat **gate**: jika gagal, tidak boleh mendapat nilai total 9+ meskipun visual bagus.
- Jika skor rata-rata ≥9 tetapi satu aspek P0 <9, rilis belum lulus.
- Jangan mengklaim skor user satisfaction 9+ tanpa usability test. Gunakan istilah `heuristic review score` sampai dites dengan pengguna.

## 5. Design system — token awal yang harus divalidasi

Gunakan CSS variables semantik yang sudah ada jika proyek memilikinya; jangan membuat token duplikat. Palette di bawah adalah baseline arah warna dan harus diuji dengan contrast checker sebelum dianggap final.

### Light Mode

| Token | Nilai baseline | Penggunaan |
|---|---|---|
| `--bg` | `#F7F7F2` | Kanvas warm ivory |
| `--surface` | `#FFFFFF` | Panel/form utama |
| `--surface-2` | `#EEF3EF` | Surface sekunder, selected subtle |
| `--surface-3` | `#E3EBE5` | Area tersier/disabled yang tetap jelas |
| `--text` | `#152521` | Teks utama |
| `--text-secondary` | `#40564E` | Deskripsi penting |
| `--text-muted` | `#566861` | Metadata yang masih harus terbaca |
| `--border` | `#C8D5CD` | Garis pembatas |
| `--brand` | `#176B61` | Tombol utama, link, active state |
| `--brand-strong` | `#11574F` | Hover/pressed bila diuji kontrasnya |
| `--accent` | `#B08D3C` | Aksen dekoratif terbatas; jangan untuk teks kecil tanpa uji kontras |

### Dark Mode

| Token | Nilai baseline | Penggunaan |
|---|---|---|
| `--bg` | `#0D1717` | Kanvas |
| `--surface` | `#172321` | Kartu/form utama |
| `--surface-2` | `#1D302C` | Surface sekunder |
| `--surface-3` | `#263B35` | Hover/selected surface |
| `--text` | `#F3F6F2` | Teks utama |
| `--text-secondary` | `#BDC9C2` | Teks sekunder |
| `--text-muted` | `#A0B0A7` | Metadata yang tetap terbaca |
| `--border` | `#3A4E46` | Border |
| `--brand` | `#55B8A5` | Aksen/link/active state; jangan otomatis menaruh teks putih di atasnya |
| `--brand-solid` | `#176B61` | Tombol berisi jika kontras teks sesuai |
| `--accent` | `#D0B16D` | Aksen terbatas; bukan warna body text kecil |

### Warna semantik

Pakai pasangan background + foreground yang telah diuji. Warna tidak boleh menjadi satu-satunya penanda status.

- Success: background muda hijau + teks hijau tua; ikon check dan label `Cocok`.
- Warning: background kuning muda + teks cokelat/amber tua; ikon alert dan penjelasan yang dapat ditindaklanjuti.
- Danger: background merah muda + teks merah tua; untuk kesalahan atau tindakan destruktif.
- Info: background biru muda + teks biru tua; untuk konteks/informasi.
- Unknown/uncertain: surface netral + ikon/label `Belum diketahui` atau `Perlu diperiksa`.

### Tipografi

- Pertahankan brand typography dari aplikasi sekarang jika sudah disepakati dan bekerja baik. Arah yang sesuai: Plus Jakarta Sans untuk body/UI, Manrope untuk display/heading, JetBrains Mono hanya untuk nominal atau kode jika benar-benar meningkatkan alignment.
- Body utama mobile: 14–16 px; hindari teks penting di bawah 13 px.
- Nominal penting: gunakan tabular numerals, font-weight 600–700, satuan `Rp` jelas, dan alignment konsisten.
- Heading sentence case; jangan menjadikan semua heading uppercase.
- Setiap ukuran font harus memiliki line-height dan peran token; jangan menyesuaikan font secara ad hoc per halaman.

### Spasi, bentuk, elevasi

- Basis spacing 4 px, mayoritas jarak 8/12/16/24/32 px.
- Area sentuh minimal 44×44 CSS px; ideal 48×48 untuk kontrol mobile yang sering digunakan.
- Radius: 8 px untuk input/compact controls, 12–16 px untuk kartu utama, 20 px hanya untuk bottom sheet/modal besar. Hindari setiap elemen punya radius berbeda.
- Shadow sangat lembut dan hanya untuk elevasi yang memiliki makna; pisahkan layer terutama melalui permukaan dan border.
- Border 1 px berkontras memadai; jangan memakai garis yang hampir tidak terlihat pada Light Mode.

### Icon

- Gunakan satu keluarga ikon (misalnya Lucide) dan ukuran token yang konsisten.
- Ikon dekoratif tidak perlu label; ikon yang menjadi satu-satunya isi tombol harus punya accessible label dan tooltip/teks yang tersedia ketika maknanya tidak universal.
- Jangan mencampur ikon outline, filled, emoji, dan ilustrasi berbeda gaya tanpa aturan.

## 6. Mobile layout dan navigation

### Breakpoint dan ukuran target

Uji minimal di viewport 360×800, 390×844, 430×932, 768×1024, 1024×768, dan 1440×900. Ukuran dapat disesuaikan dengan breakpoint proyek yang ada, tetapi tes tidak boleh hanya di desktop.

### Header mobile

**Posisi:** bagian atas semua screen.

- Sembunyikan breadcrumb pada layar kecil; tampilkan judul halaman utuh.
- Struktur: hamburger/back di kiri, judul singkat di tengah/kiri, paling banyak satu aksi kontekstual di kanan.
- Theme toggle dan bantuan jangan bersaing dengan aksi utama pada setiap header; pindahkan ke Menu/Pengaturan bila perlu.
- Hindari judul seperti `Ringkasan T...` atau `Laporan Ke...`.
- Aksi global `+` harus berlabel jelas (`+ Catat` atau `+ Tambah`) dan tidak menduplikasi aksi spesifik halaman.

### Bottom navigation

Pertahankan maksimal 5 tujuan utama:
1. **Beranda**
2. **Belanja**
3. **Cek Sisa**
4. **Setoran**
5. **Menu**

- Label harus terbaca, active state menggabungkan warna + ikon + indikator/weight, bukan warna saja.
- Saat keyboard terbuka dan pengguna sedang mengetik, bottom navigation disembunyikan atau direduksi agar tidak menghabiskan area kerja; pastikan implementasi stabil di Chrome Android.
- Beri safe-area padding, jangan sampai tombol/focus tertutup bottom bar.
- Menu aktif sebagai parent tidak boleh membuat pengguna mengira dirinya sudah kembali ke halaman Menu; sediakan state parent yang berbeda.

### Drawer / Menu

- Kelompokkan: `Operasional` (Barang, Belanja, Cek Sisa, Setoran), `Hasil` (Laporan), `Lainnya` (Asisten, Riwayat, Pengaturan).
- Samakan nama menu dengan nama judul halaman.
- Footer drawer diringkas menjadi brand + versi kecil + status backup jika statusnya nyata. Hapus counter `3 Barang / 3 Riwayat` dari footer jika tidak membantu navigasi.
- Drawer ditutup oleh X, tap di luar, Escape pada keyboard, serta pemilihan menu.

## 7. Audit dan spesifikasi tiap halaman

### 7.1 Beranda / Ringkasan Toko

**Masalah saat ini:** deskripsi panjang, kartu metrik berulang, kartu `Alur Kerja Harian Toko · 4 Langkah Rutin` terlalu besar, tombol aksi bisa terbungkus tidak seimbang, angka kas negatif tidak cukup kontekstual.

**Struktur target dari atas ke bawah:**
1. Header: `Beranda` + tanggal/periode yang relevan.
2. **Satu kartu status/tindakan berikutnya**: contoh `Ada 3 barang yang belum dicek` + `Cek sisa`, atau `Setoran menunggu dicatat` + `Catat setoran`. Jangan tampilkan bila tidak relevan.
3. Ringkasan maksimal 4 metrik, ideal grid 2×2 jika seluruh angka tetap terbaca:
   - Nilai penjualan terhitung
   - Laba (dengan periode dan keterangan kepastian)
   - Uang yang perlu diserahkan/atau ringkasan serah-terima
   - Nilai modal barang tersisa
4. Bagian `Aktivitas terbaru` maksimal 3 baris dengan `Lihat semua`.
5. Panduan 4 langkah diringkas menjadi satu baris yang dapat dibuka; tidak tampil sebagai empat kartu tinggi pada default state.

**Microcopy:**
- Lama: `Dasbor catatan harian: kontrol sisa rak, laba operasional, dan mutasi kas laci.`
- Baru: `Lihat stok, hasil toko, dan setoran karyawan.`
- Hindari istilah yang tidak diperlukan, misalnya `mutasi kas`.

**Acceptance:** pengguna dapat melihat status toko dan menemukan aksi berikutnya dalam 3 detik; layar awal tidak memerlukan scroll untuk menemukan tindakan utama.

### 7.2 Katalog Barang

**Masalah saat ini:** empat kartu statistik besar memakan tinggi; pencarian/filter/sort/layout menjadi baris kontrol panjang; tabel desktop menyusut sehingga nama barang patah dan perlu horizontal scroll.

**Mobile:**
1. Judul `Barang`.
2. Search field dengan placeholder `Cari nama barang` dan tombol `+ Barang`.
3. Filter chip kecil: `Semua`, `Stok ada`, `Habis`. Filter lain dalam menu `Filter`.
4. Ringkasan mini: `6 barang · 64 pcs tersedia · 0 habis` (angka berasal dari data, tidak hardcoded).
5. Daftar produk responsif, bukan tabel desktop diperkecil. Setiap row menampilkan:
   - Nama barang dan satuan.
   - Stok yang mudah ditemukan.
   - Harga jual.
   - Badge status.
   - Tap membuka detail; aksi sekunder di menu `⋯` dengan accessible label.
6. Detail produk memuat modal stok, isi kemasan, riwayat harga, dan histori perubahan pada bagian yang dapat diperluas.

**Desktop/tablet:** tabel penuh boleh dipertahankan dengan header yang jelas, angka rata kanan, sorting konsisten, dan filter. Jangan merusak desktop demi mobile; gunakan layout responsif berbeda jika perlu.

**Search UX:** ikon search dekoratif; tidak mengambil fokus/click target kecuali memang tombol clear. Clear `×` muncul jika ada teks. Tidak memunculkan ikon yang menimpa cursor. Query tidak hilang ketika kembali dari detail.

**Empty state:** jika filter `Habis` menghasilkan nol barang, gunakan `Tidak ada barang yang stoknya habis.` CTA utama `Lihat semua barang`; CTA tambah barang bersifat sekunder.

### 7.3 Belanja barang

**Tujuan:** mencatat pembelian/restock sekali dengan jumlah langkah minimum, menghitung stok/unit/modal dan nilai penjualan potensial tanpa membuat pengguna memahami rumus.

**Urutan field:**
1. `Nama barang` — searchable select, mendahulukan produk yang sudah ada.
2. `Jumlah kemasan` — contoh 2.
3. `Satuan beli` — dus/pak/renceng/toples atau satuan kemasan produk.
4. `Isi per kemasan` — otomatis terisi dari riwayat; bisa diubah jika kemasan berubah.
5. `Harga beli per kemasan` — prefix `Rp` dengan slot terpisah agar tidak menimpa angka/cursor.
6. `Harga jual per item` — harga berlaku; jika sudah ada tampilkan nilai sekarang dan pilihan ganti.
7. `Dibayar dari` — default dari pengaturan yang pernah dikonfirmasi, tetapi dapat diubah pada transaksi. Jangan asumsi diam-diam jika belum ada pilihan.

**Derived preview, bukan field yang harus diisi:**
- `Jumlah barang masuk: 48 bungkus`
- `Total belanja: Rp192.000`
- `Modal per bungkus: Rp4.000` (jika dapat dihitung)
- `Keuntungan Jual: Rp336.000` dengan caption **`Nilai penjualan jika semua barang terjual — belum dikurangi modal.`**

Jangan memanggil nilai `Keuntungan Jual` sebagai laba. Jika modal tidak diketahui, beri label `Modal belum diketahui` dan jangan membuat laba pasti.

**Layout mobile:** single-column; dua field boleh berdampingan hanya jika singkat dan tidak membingungkan (mis. jumlah kemasan + satuan). Field harga, nama, dan satuan tidak boleh dipaksa ke tiga kolom.

**Primary action:** `Tinjau belanja` atau `Simpan belanja` sesuai arsitektur sekarang. Jangan menambahkan langkah konfirmasi kedua yang tidak perlu apabila preview jelas dan perubahan normal berisiko rendah. Aksi berisiko tetap konfirmasi.

**Acceptance:** data kemasan lama otomatis diisi jika tersedia; perubahan isi kemasan tidak menimpa histori lama; angka preview selalu konsisten dengan engine.

### 7.4 Cek Sisa Fisik — prioritas inti tertinggi

**Masalah saat ini:** tabel sempit/horizontal scroll. Aktivitas ini dilakukan banyak produk sekaligus dan harus secepat menulis angka di kertas.

**Mobile layout yang dituju:** daftar input ringkas satu produk per row. Tidak menggunakan tabel 6+ kolom. Baris memuat:
- Nama barang (maksimal dua baris), jumlah stok tersedia/label context singkat.
- Input besar `Sisa sekarang` dengan keyboard numerik.
- Subtext hasil: `Perkiraan terjual: 12` jika dapat dihitung, atau `Belum bisa dihitung` jika data belum cukup.
- Akses `Rusak / Dipakai / Tidak tahu` hanya jika ada pengurangan yang perlu dikategorikan, atau melalui detail baris.

**Header di atas daftar:**
- `Cek sisa barang`
- `Masukkan jumlah yang masih ada di toko.`
- Pencarian/filter kategori opsional hanya jika jumlah produk memang banyak.
- `x dari y barang diisi` sebagai progres kecil; jangan tampilkan kartu progres besar.

**Perilaku:**
- Fokus pertama diarahkan ke input pertama hanya jika tidak mengganggu screen reader/keyboard.
- Enter/Next keyboard memindah ke input berikutnya.
- Nilai yang sudah diisi tidak hilang saat validasi.
- Tombol simpan dan ringkasan ditempatkan dalam sticky bottom action hanya bila tidak menutupi field/keyboard.
- Saat keyboard terbuka, hide bottom nav; beri ruang pada tombol utama.
- Baris belum disentuh bukan error.
- Error hanya pada baris yang bermasalah, bukan semua baris.
- Jika sisa > tersedia, jelaskan: `Sisa melebihi stok yang tercatat. Periksa belanja yang belum dicatat atau hitung kembali.` Tampilkan pilihan yang relevan, jangan otomatis mencatat penjualan negatif.
- Jika penurunan janggal, tampilkan soft prompt hanya bila riwayat cukup: `Jumlahnya lebih banyak dari biasanya. Ada barang rusak atau dipakai?` Pilihan: `Rusak`, `Dipakai`, `Tidak tahu`, `Lanjut sebagai terjual` (sesuai aturan bisnis).

**Ringkasan hasil:** `8 barang diperbarui. Perkiraan 47 barang terjual.` Sertakan tanda `Perlu diperiksa` pada bagian yang tidak pasti.

**Acceptance:** 20 produk dapat dicatat dengan mengisi kolom sisa saja, tanpa horizontal scroll, tanpa membuka 20 form, tanpa pesan error untuk baris kosong, dan tanpa kehilangan input ketika keyboard berubah.

### 7.5 Setoran karyawan kepada owner

**Definisi yang harus terlihat konsisten:** karyawan menyerahkan uang kepada owner; owner mencatat jumlah yang benar-benar diterima. Ini bukan setoran bank, bukan biaya, dan bukan laba baru.

**Terminologi layar:**
- `Uang yang perlu diserahkan` = hasil hitung menurut catatan, dengan sumber/ketidakpastian yang jelas.
- `Uang diterima owner` = jumlah aktual yang dicatat owner.
- `Selisih setoran` = perbedaan aktual terhadap yang seharusnya.
- Status: `Cocok`, `Perlu diperiksa`, `Belum cocok`, atau `Belum ada setoran`.

**Jangan tampilkan angka negatif sendirian.** Jika saldo catatan negatif karena penjualan baru dihitung saat cek sisa atau karena urutan pembelian/penjualan, gunakan copy yang menjelaskan sumbernya, misalnya: `Saldo catatan sementara minus Rp228.000. Ada belanja yang sudah tercatat sebelum penjualan terhitung. Periksa sumber uang dan cek sisa.` Copy ini hanya boleh digunakan jika penjelasan itu benar-benar didukung detail perhitungan.

**Layout:**
1. Periode otomatis terpilih; sediakan cara mengubahnya bila diperlukan.
2. Card ringkas `Perlu diserahkan` dan `Sudah diterima`.
3. Field nominal `Uang diterima owner` dengan format Rupiah.
4. Jika selisih: tampilkan satu alasan utama atau daftar kemungkinan yang netral; hindari kata yang menyiratkan karyawan mengambil uang.
5. Riwayat setoran dalam periode.

**Aturan:** uang dari belanja pribadi/owner tidak boleh memotong kas yang dipegang karyawan. Pembelian/pengeluaran yang dibayar dari uang toko mengikuti sumber uang kejadian. Setoran tidak menambah penjualan dan tidak menambah laba.

**Acceptance:** owner dapat menjawab: `Berapa seharusnya diterima?`, `Berapa yang benar-benar diterima?`, `Berapa selisihnya?`, `Apa yang perlu diperiksa?` tanpa membuka dokumentasi.

### 7.6 Laporan Toko dan ekspor

**Urutan:** pilih periode → ringkasan → bagian detail → aksi ekspor. Jangan membuat banner panjang mengalahkan angka.

**Ringkasan:**
- `Penjualan terhitung`
- `Keuntungan Jual` (nilai penjualan potensial semua barang, dengan caption)
- `Laba kotor`
- `Laba bersih`
- `Pengeluaran`
- `Setoran diterima owner`
- `Selisih/perlu diperiksa`
- `Barang belum dicek/modal belum diketahui`

Jangan menaruh semua indikator sebagai kartu besar. Gunakan 2–3 ringkasan utama dan detail tabel yang ringkas.

**Peringatan rekonsiliasi:** tampilkan sebagai banner yang memiliki kontras jelas. Misal:
- Judul: `Perlu diperiksa`
- Kalimat: `Nilai penjualan bukan laba. Laba kotor baru dihitung setelah modal barang terjual dikurangi.`
- Link: `Lihat perhitungan`
Jangan gunakan teks kuning pucat di atas krem, badge transparan, atau paragraf teknis yang berulang.

**Ekspor yang ditargetkan:** PDF, Excel (.xlsx), CSV, JSON. Setiap output memiliki periode, tanggal pembuatan, nama toko, satuan, footer/halaman bila relevan, subtotal, dan catatan kepastian. PDF dan Excel harus benar-benar dihasilkan dan dibuka saat diuji; jangan klaim selesai hanya karena tombol ada.

### 7.7 Asisten Catatan

- OFF default; semua fungsi inti masih dapat dilakukan melalui form/list tanpa AI.
- Mode ON yang belum terhubung model hanya boleh menunjukkan status kesiapan atau input parser lokal yang benar-benar berfungsi; jangan mengklaim “AI berhasil” jika tidak ada model.
- Bahasa natural contoh: `Rabu mie sisa 8, Saltchees 6.`
- Parser membuat preview usulan, bukan langsung menyimpan.
- Jika ada ambiguitas, tanyakan satu pertanyaan terfokus.
- Tombol `Simpan catatan` aktif hanya bila nilai wajib dan ketidakpastian telah diselesaikan sesuai aturan.

### 7.8 Jejak Riwayat

- Gunakan timeline/list kronologis dengan tanggal dan jenis kejadian.
- Urutkan per waktu; nominal memakai alignment kanan/angka tabular.
- Tampilkan ringkas: `Belanja — Mie — Rp192.000` lalu detail dapat dibuka.
- Bedakan `Diedit`, `Dibatalkan`, dan `Koreksi periode tertutup`.
- Jangan menampilkan aksi delete yang terlihat seperti menghilangkan histori; gunakan `Batalkan catatan` atau `Buat koreksi` sesuai keadaan.
- Sebelum tindakan destruktif, konfirmasi dengan ringkasan dampak. Setelah berhasil, toast menjelaskan akibatnya.

### 7.9 Pengaturan

Kelompokkan menjadi `Tampilan`, `Cara pencatatan`, `Data & backup`, `Tentang aplikasi`.
- Tema: `Ikuti perangkat`, `Terang`, `Gelap` jika implementasi mendukung ketiga mode; kalau tidak, `Terang/Gelap`.
- Asisten AI: OFF/ON dengan keterangan jujur, tanpa menyembunyikan bahwa fitur ON belum terhubung jika memang demikian.
- Ekspor backup dan pulihkan data ditempatkan jelas, dengan tanggal backup terakhir bila benar-benar diketahui.
- `Muat data contoh` hanya ada di pengembangan atau diberi label tegas.
- `Kosongkan semua data` disimpan paling bawah dalam area `Tindakan berisiko`, meminta konfirmasi eksplisit, dan tidak pernah ditampilkan sebagai tombol primer.

## 8. UX writing — bahasa Indonesia sehari-hari

### Prinsip

- Satu kalimat menyampaikan satu gagasan.
- Mulai dengan hasil atau tindakan, bukan penjelasan sistem.
- Pakai kata kerja jelas untuk tombol: `Simpan belanja`, `Cek sisa`, `Catat setoran`, `Unduh PDF`.
- Jangan memakai all-caps untuk teks konten.
- Jangan menggunakan istilah teknis jika istilah sehari-hari cukup.
- Jangan menaruh instruksi yang sama di judul, subtitle, kartu, dan helper text sekaligus.
- Tampilkan penjelasan saat dibutuhkan melalui `Kenapa?` / `Lihat perhitungan`.
- Pesan validasi spesifik, positif, dan menyatakan tindakan berikutnya.

### Kamus UI yang dikunci

| Gunakan | Jangan jadikan bahasa utama |
|---|---|
| Barang | Inventory |
| Belanja | Purchase transaction |
| Sisa sekarang | Stock count checkpoint |
| Modal barang | HPP/COGS |
| Keuntungan Jual + caption definisi | Laba untuk nilai penjualan potensial |
| Penjualan terhitung | Revenue calculation |
| Laba kotor | Gross profit |
| Laba bersih | Net profit (boleh di detail teknis) |
| Pengeluaran toko | Operating expense |
| Uang yang perlu diserahkan | Cash reconciliation balance |
| Uang diterima owner | Deposit/owner remittance tanpa penjelasan |
| Selisih setoran | Variance |
| Perlu diperiksa | Anomaly state |
| Riwayat | Audit log |
| Batalkan catatan | Delete transaction |
| Nilai modal barang tersisa | Inventory asset value |

### Contoh microcopy

| Situasi | Copy yang ditargetkan |
|---|---|
| Kosong pada Barang | `Belum ada barang. Tambahkan barang pertama untuk mulai mencatat belanja.` |
| Hasil filter kosong | `Tidak ada barang pada pilihan ini.` CTA `Tampilkan semua barang`. |
| Input jumlah kosong setelah submit | `Masukkan jumlah sisa barang.` |
| Stok lebih besar dari tersedia | `Sisa melebihi stok yang tercatat. Periksa belanja yang belum dicatat atau hitung kembali.` |
| Modal belum diketahui | `Modal barang ini belum diketahui. Hasil untung belum lengkap.` |
| Network putus | `Belum tersambung. Data belum disimpan. Periksa koneksi, lalu coba lagi.` |
| Preview | `Belum disimpan — periksa angka sebelum menyimpan.` |
| Save sukses | `Tersimpan. 8 barang diperbarui.` |
| Setoran cocok | `Setoran cocok dengan catatan.` |
| Setoran tidak pasti | `Nominal terlihat cocok, tetapi masih ada data yang belum pasti.` |
| Status perubahan | `Perubahan disimpan dalam riwayat.` |
| Backup belum dibuat | `Belum ada backup. Unduh salinan data untuk menyimpannya.` |

### Bahasa yang harus dihindari

Hindari: `Terjadi error`, `Invalid`, `Oops`, `Submit`, `Click here`, `Data tidak valid` tanpa penjelasan, instruksi bertingkat, dan jargon. Hindari juga “aman/beres” jika ada data yang belum pasti.

## 9. State dan feedback seluruh aplikasi

Setiap halaman harus punya state yang konsisten:

- **Loading:** skeleton mengikuti bentuk konten; tidak memblokir seluruh layar untuk pekerjaan kecil; tidak menampilkan angka palsu.
- **Empty:** satu kalimat yang menyebut apa yang kosong dan satu CTA paling relevan.
- **Error input:** dekat dengan field dan terhubung secara aksesibel; input yang sudah diisi tetap ada.
- **Error layanan:** jelas membedakan error input dari masalah koneksi/server; jangan menampilkan stale data seolah terkini.
- **Success toast:** menyatakan apa yang terjadi, misalnya `Belanja tersimpan — 48 bungkus masuk.`
- **Undo:** hanya jika mekanisme undo benar-benar bekerja dan aman; setelah periode ditutup gunakan alur koreksi yang sesuai.
- **Saving/pending:** disable tombol yang relevan, tampilkan `Menyimpan…`, cegah double-submit.
- **Uncertain state:** selalu berlabel, tidak boleh disamarkan oleh warna yang seolah sukses.

Toast tidak boleh menutupi field, pesan validasi, tombol utama, atau bottom navigation. Sediakan live region untuk screen reader, duration cukup, dan jangan hanya mengandalkan toast untuk kesalahan penting.

## 10. Motion dan micro-interaction

- Gunakan Motion/Framer Motion yang sudah ada; jangan memasang pustaka tambahan jika tidak diperlukan.
- Durasi baseline: 120–200 ms untuk pressed/focus feedback, 160–240 ms untuk sheet/modal/transition ringan.
- Ease-out pada elemen masuk; jangan overshoot atau bounce pada UI keuangan.
- Motion harus menegaskan sebab-akibat: buka detail, simpan, filter, toast, sheet.
- Hindari parallax, background motion terus-menerus, ripple dekoratif yang tidak memberi feedback, animasi angka yang mengubah persepsi nilai, dan shimmer yang terlalu lama.
- Hormati `prefers-reduced-motion`; reduced motion harus menghilangkan perpindahan besar, bukan sekadar memperlambatnya.
- Animasi tidak boleh menunda aksi utama atau menyembunyikan state loading.

## 11. Aksesibilitas dan keterbacaan

Target: WCAG 2.2 AA sebagai baseline desain dan pengujian.

- Teks biasa: kontras minimum 4.5:1; teks besar minimum 3:1.
- Kontrol/status/grafik penting: kontras nonteks yang memadai (target WCAG 3:1 untuk komponen grafis penting).
- Jangan memakai warna sebagai satu-satunya sinyal; status memiliki teks + ikon.
- Target sentuh praktis 44–48 CSS px, jarak yang memadai.
- Focus visible, tidak tertutup sticky header/nav/modal, urutan tab mengikuti logika.
- Setiap input memiliki label terlihat; placeholder bukan pengganti label.
- Prefix `Rp` tidak menutupi input dan tidak ikut masuk sebagai karakter yang merusak caret.
- Pesan error terhubung menggunakan `aria-describedby`; input invalid diumumkan semantik.
- Dialog: nama, role, fokus awal/loop/dismissal, Escape jika sesuai, dan return focus.
- Gambar/ikon dekoratif disembunyikan dari screen reader; tombol icon-only memiliki accessible name.
- Uji zoom/text scaling, Android Chrome, keyboard virtual, dan landscape bila diperlukan.

## 12. Responsive behavior — detail

### 360–430 px
- Tidak ada horizontal page scroll.
- Jangan menampilkan tabel desktop berscroll horizontal pada alur harian.
- Form mayoritas satu kolom.
- Sticky bottom action tidak boleh menutupi field yang sedang diedit.
- Bottom nav tidak boleh tumpang tindih dengan keyboard.
- Judul tidak terpotong; angka rupiah tidak terpecah secara membingungkan.

### 768 px
- Gunakan ruang tambahan untuk 2 kolom pada ringkasan bila terbaca.
- Form boleh 2 kolom hanya untuk pasangan field yang saling berhubungan.
- List dapat berubah menjadi table-like rows apabila tidak menambah beban horizontal.

### ≥1024 px
- Tabel lengkap diperbolehkan.
- Gunakan whitespace dan lebar konten yang terkendali; jangan memperlebar form ke seluruh layar.
- Pertahankan hirarki visual yang sama dengan mobile, bukan membangun UI yang tidak konsisten.

## 13. Sistem ekspor dan laporan

Meskipun ini audit mobile, tombol ekspor dan output laporan adalah bagian dari pengalaman end-to-end.

- Menu `Ekspor laporan` memiliki pilihan `PDF`, `Excel (.xlsx)`, `CSV`, `Backup JSON`.
- Bedakan **laporan** (PDF/XLSX/CSV) dari **backup data** (JSON) agar pengguna tidak salah menganggap CSV sebagai backup penuh.
- PDF: A4, nama toko, judul, periode, tanggal dibuat, ringkasan, tabel yang tidak terpotong, subtotal, halaman, catatan data belum pasti.
- XLSX: sheet Ringkasan + Rincian, header dan filter, format rupiah/tanggal, freeze header, lebar kolom, print area.
- CSV: UTF-8, header, nilai yang tidak merusak delimiters, catatan periode jika cocok.
- JSON: validasi skema saat import, preview jumlah item/peristiwa, konfirmasi jika akan mengubah data.
- Di mobile, gunakan bottom sheet untuk memilih format dan periode; tombol download tidak berdesakan dalam 4 tombol kecil.
- Beri status progres saat ekspor besar. Jangan menampilkan toast sukses sebelum file berhasil dibuat.

## 14. Testing plan wajib

### Visual regression / viewport

- 360×800, 390×844, 430×932, 768×1024, 1024×768, 1440×900.
- Light dan Dark untuk semua screen.
- Font size normal dan text zoom 200% pada alur utama.
- Screenshot regression untuk: Beranda, Barang, Belanja, Cek Sisa, Setoran, Laporan, Riwayat, Pengaturan, modal, toast, error, loading, empty.

### Task-based tests

1. Tambah belanja 2 dus × 24, harga beli Rp96.000/dus, harga jual Rp7.000/pcs.
2. Pastikan jumlah barang masuk 48, total belanja Rp192.000, Keuntungan Jual Rp336.000 dan caption belum dikurangi modal.
3. Cek sisa 10 pcs: sistem menunjukkan 38 terjual jika stok/penyesuaian lain pasti; nilai penjualan terhitung Rp266.000, modal barang terjual Rp152.000, laba kotor Rp114.000.
4. Cek 20 barang dari satu halaman dengan hanya mengisi sisa; tidak ada horizontal scroll.
5. Stok tersisa > tersedia; sistem tidak mencatat penjualan negatif dan tidak menghapus input.
6. Barang rusak/dipakai/tidak diketahui tidak diduplikasi sebagai penjualan.
7. Setoran karyawan Rp aktual; bandingkan dengan yang seharusnya; setoran tidak menambah laba.
8. Belanja dengan uang pribadi owner tidak mengurangi uang yang dipegang karyawan.
9. Modal belum diketahui; laba tidak disajikan seolah-olah pasti.
10. Ekspor PDF/XLSX/CSV/JSON; file benar-benar dapat dibuka dan nilainya sesuai dengan layar.
11. Simulasi gagal koneksi saat save; tidak menampilkan sukses palsu dan tidak menduplikasi transaksi saat retry.
12. Asisten AI OFF: semua alur inti tetap dapat diselesaikan. AI ON tanpa model tidak boleh menyatakan pemrosesan model berhasil.

### Accessibility QA

- Axe/Playwright atau alat yang sesuai untuk automated checks.
- Keyboard-only untuk semua dialog, drawer, filter, dan form desktop.
- Screen reader label dasar; error text dan status diumumkan.
- Manual contrast checks untuk seluruh token pasangan teks/background di Light dan Dark.
- Tap target, focus visibility, reduced motion, dan safe-area checks.

### Performance/quality

- Jalankan build, lint, typecheck, unit test, E2E, dan browser verification sesuai stack proyek yang sekarang.
- Pantau Core Web Vitals jika dapat diukur: LCP ≤2.5 s, INP ≤200 ms, CLS ≤0.1 pada persentil ke-75 sebagai target web umum, bukan jaminan tanpa pengukuran lapangan.
- Jangan menambah animasi/dependency apabila meningkatkan input lag atau ukuran bundle tanpa manfaat yang terbukti.

## 15. Prioritas implementasi

### Sprint 0 — audit source, tanpa perubahan destruktif
- Petakan file/layout/token/komponen yang sudah ada.
- Temukan duplicate CSS/token, komponen tabel mobile, currency inputs, status copy, dan business logic setoran.
- Catat baseline screenshot dan perintah build/test.

### Sprint 1 — P0: readability & financial trust
- Perbaiki pasangan warna Light/Dark dan contrast warnings/badges.
- Perbaiki prefix Rp agar tidak menimpa nilai/cursor.
- Perbaiki nama header/menu dan search field focus behavior.
- Audit label/rumus `Keuntungan Jual` serta setoran karyawan ke owner.
- Perbaiki error yang muncul sebelum input relevan.

### Sprint 2 — P0: mobile core tasks
- Ganti tabel produk mobile menjadi list responsif.
- Optimalkan Cek Sisa massal: satu input per baris, no horizontal scroll.
- Rampingkan Belanja dan ringkasan preview.
- Rapikan sticky action + keyboard + bottom nav.

### Sprint 3 — P1: information hierarchy and copy
- Ringkas Beranda dan alur 4 langkah.
- Rapikan Setoran, Laporan, Riwayat, Pengaturan.
- Terapkan kamus UX writing yang konsisten.
- Sederhanakan drawer.

### Sprint 4 — P2: premium polish
- Standarkan spacing/radius/iconography.
- Motion kecil dan reduced-motion.
- Skeleton, empty states, toast, modal, transitions.
- Export menu responsive.

### Sprint 5 — validation before “9+” status
- Jalankan semua viewport/tema/tasks/accessibility/performance tests.
- Beri skor ulang per dimensi menggunakan rubrik bagian 4.
- Laporkan skor final hanya untuk aspek yang benar-benar diuji.

## 16. Laporan implementasi yang wajib diminta dari Google AI Studio

Setelah mengubah kode, minta AI Studio melaporkan:
1. File yang diubah dan alasan.
2. Masalah per halaman yang diperbaiki.
3. Tabel sebelum → sesudah untuk copy/label yang berubah.
4. Hasil build/lint/typecheck/tests dengan perintah nyata.
5. Viewport dan tema yang diverifikasi; lampirkan screenshot bila tersedia.
6. Hasil pemeriksaan kontras dan accessibility.
7. Risiko yang masih tersisa, terutama rumus uang, setoran, dan penyimpanan.
8. Daftar item rubric 9+ yang sudah terbukti lulus dan belum diuji.

Jangan menerima jawaban “semua sudah sempurna” tanpa diff dan bukti. Jangan mengunci semua nilai di 9+ hanya karena UI sudah tampak menarik.

## 17. Definition of Done

Revisi hanya disebut `UI/UX Optimization v2.0 — Ready for Review` jika:
- [ ] Tidak ada horizontal scroll halaman pada 360 px untuk alur inti.
- [ ] Light Mode memiliki kontras memadai untuk teks, badge, alert, placeholder, border, dan field.
- [ ] Dark Mode tetap konsisten dan tidak rusak oleh perbaikan Light Mode.
- [ ] Header tidak memotong judul; navigasi tidak menutupi keyboard/konten.
- [ ] Belanja dan Cek Sisa dapat dilakukan dengan langkah minimum.
- [ ] `Keuntungan Jual` tidak disalahnamakan sebagai laba.
- [ ] Setoran karyawan → owner dijelaskan dan dihitung dengan makna yang benar.
- [ ] Semua pesan penting menggunakan bahasa mudah dipahami dan menyebut tindakan berikutnya.
- [ ] Loading/empty/error/success/uncertain state dibedakan jelas.
- [ ] PDF/XLSX/CSV/JSON bila ditampilkan benar-benar berfungsi atau diberi status belum tersedia; tidak ada tombol palsu.
- [ ] Build dan automated tests lulus pada lingkungan proyek; tes yang tidak dapat dijalankan dilaporkan sebagai belum diverifikasi.
- [ ] Skor heuristik tiap dimensi dicatat dengan bukti; P0 yang gagal membuat rilis belum lulus 9+.

---

## 18. Referensi

Gunakan `REFERENCE_LIBRARY.md` untuk daftar URL, penjelasan, dan hirarki referensi. Urutan bobot keputusan:

1. Integritas produk/keuangan TOKO SAKALA.
2. Pedoman aksesibilitas (WCAG 2.2 AA) dan pola sistem desain resmi.
3. Riset usability (Apple HIG, GOV.UK, Primer, NN/G, Baymard).
4. Data pengujian pada perangkat nyata.
5. Inspirasi visual Dribbble/Pinterest/Behance.

Referensi visual tidak boleh mengalahkan kebutuhan penggunaan nyata.
